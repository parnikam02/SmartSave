
import React, { useState } from 'react';
import { Transaction, TransactionType, Category } from '../types';
import { Coffee, Car, FileText, ShoppingBag, Music, HelpCircle, Smartphone, CreditCard, Banknote, HeartPulse } from 'lucide-react';

interface Props {
  transactions: Transaction[];
}

const getCategoryIcon = (category: string) => {
  switch (category) {
    case Category.FOOD: return <Coffee size={18} />;
    case Category.TRAVEL: return <Car size={18} />;
    case Category.BILLS: return <FileText size={18} />;
    case Category.SHOPPING: return <ShoppingBag size={18} />;
    case Category.ENTERTAINMENT: return <Music size={18} />;
    case Category.HEALTH: return <HeartPulse size={18} />;
    default: return <HelpCircle size={18} />;
  }
};

const getPaymentModeIcon = (mode?: string, source?: string) => {
    if (source === 'GPay' || source === 'PhonePe' || mode === 'UPI') return <Smartphone size={10} />;
    if (mode === 'Cash') return <Banknote size={10} />;
    if (mode === 'Credit Card' || mode === 'Debit Card') return <CreditCard size={10} />;
    return null;
};

const RecentTransactions: React.FC<Props> = ({ transactions }) => {
  const [filter, setFilter] = useState<'All' | 'Food' | 'Travel' | 'Bills' | 'Cards' | 'Cash'>('All');

  const filteredTxs = transactions.filter(t => {
      if (filter === 'All') return true;
      if (filter === 'Food') return t.category === Category.FOOD;
      if (filter === 'Travel') return t.category === Category.TRAVEL;
      if (filter === 'Bills') return t.category === Category.BILLS;
      if (filter === 'Cards') return t.paymentMode === 'Credit Card' || t.paymentMode === 'Debit Card';
      if (filter === 'Cash') return t.paymentMode === 'Cash';
      return true;
  });

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="p-4 border-b border-gray-100 bg-gray-50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <h3 className="font-semibold text-gray-700">Recent Activity</h3>
        
        {/* Tabs */}
        <div className="flex gap-1 bg-gray-200 p-1 rounded-lg overflow-x-auto max-w-full">
            {['All', 'Food', 'Travel', 'Bills', 'Cards', 'Cash'].map(f => (
                <button
                    key={f}
                    onClick={() => setFilter(f as any)}
                    className={`px-3 py-1 rounded text-xs font-medium whitespace-nowrap transition ${filter === f ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                    {f}
                </button>
            ))}
        </div>
      </div>
      
      <div className="divide-y divide-gray-100">
        {filteredTxs.length === 0 ? (
            <div className="p-8 text-center text-gray-400 text-sm">No transactions found for {filter}</div>
        ) : (
            filteredTxs.map((t) => (
            <div key={t.id} className="p-4 flex items-center justify-between hover:bg-gray-50 transition">
                <div className="flex items-center gap-4">
                <div className={`p-2 rounded-full ${t.type === TransactionType.EXPENSE ? 'bg-red-50 text-red-500' : 'bg-green-50 text-green-500'}`}>
                    {getCategoryIcon(t.category)}
                </div>
                <div>
                    <p className="font-medium text-gray-800">{t.description}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                    <span>{new Date(t.date).toLocaleDateString()}</span>
                    <span>•</span>
                    <span>{t.category}</span>
                    
                    {(t.source || t.paymentMode) && (
                        <>
                        <span>•</span>
                        <span className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-gray-600 ${t.paymentMode === 'Credit Card' ? 'bg-orange-100 text-orange-700' : 'bg-gray-100'}`}>
                            {getPaymentModeIcon(t.paymentMode, t.source)}
                            {t.paymentMode || t.source}
                        </span>
                        </>
                    )}
                    </div>
                </div>
                </div>
                <div className={`font-semibold ${t.type === TransactionType.EXPENSE ? 'text-red-600' : 'text-green-600'}`}>
                {t.type === TransactionType.EXPENSE ? '-' : '+'}₹{t.amount}
                </div>
            </div>
            ))
        )}
      </div>
    </div>
  );
};

export default RecentTransactions;
