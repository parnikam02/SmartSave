import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, PieChart, Wallet, BrainCircuit, PlusCircle, Plane, ReceiptText, ShieldAlert } from 'lucide-react';
import { getCurrentUser } from '../services/storageService';
import { User } from '../types';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    setUser(getCurrentUser());
  }, []);

  const navItems = [
    { path: '/', label: 'Dashboard', icon: Home },
    { path: '/lifestyle', label: 'Lifestyle & Plans', icon: Plane },
    { path: '/bills', label: 'Bills & Utilities', icon: ReceiptText },
    { path: '/analytics', label: 'Analytics', icon: PieChart },
    { path: '/wallet', label: 'Wallet', icon: Wallet },
    { path: '/advisor', label: 'AI Advisor', icon: BrainCircuit },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden bg-indigo-600 text-white p-4 flex justify-between items-center sticky top-0 z-50">
        <h1 className="text-xl font-bold">SmartSave</h1>
        <Link to="/add" className="text-white">
          <PlusCircle size={24} />
        </Link>
      </div>

      {/* Sidebar (Desktop) */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-gray-200 h-screen sticky top-0">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-indigo-600 flex items-center gap-2">
            <Wallet className="fill-indigo-100" /> SmartSave
          </h1>
        </div>
        <nav className="flex-1 px-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-indigo-50 text-indigo-600 font-medium'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Icon size={20} />
                {item.label}
              </Link>
            );
          })}

          {user?.role === 'admin' && (
              <Link
                to="/admin"
                className="flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 transition-colors font-medium mt-4 border-t border-gray-100"
              >
                <ShieldAlert size={20} />
                Admin Panel
              </Link>
          )}
        </nav>
        <div className="p-4 border-t border-gray-100">
           <Link to="/add" className="flex items-center justify-center gap-2 w-full bg-indigo-600 text-white py-3 rounded-lg hover:bg-indigo-700 transition">
             <PlusCircle size={18} /> Add Transaction
           </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto mb-16 md:mb-0">
        <div className="max-w-5xl mx-auto">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around p-3 z-50 safe-area-bottom overflow-x-auto">
        {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex flex-col items-center gap-1 text-xs min-w-[60px] ${
                  isActive ? 'text-indigo-600' : 'text-gray-500'
                }`}
              >
                <Icon size={24} />
                <span className="whitespace-nowrap scale-90">{item.label}</span>
              </Link>
            );
          })}
      </div>
    </div>
  );
};

export default Layout;