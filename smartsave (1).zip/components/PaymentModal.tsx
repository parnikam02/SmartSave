
import React, { useState } from 'react';
import { Lock, Smartphone, ShieldCheck, X } from 'lucide-react';
import { verifyPin } from '../services/storageService';

interface PaymentModalProps {
    isOpen: boolean;
    amount: number;
    payee: string;
    onClose: () => void;
    onSuccess: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, amount, payee, onClose, onSuccess }) => {
    const [step, setStep] = useState<'confirm' | 'pin' | 'processing'>('confirm');
    const [pin, setPin] = useState('');
    const [error, setError] = useState('');

    if (!isOpen) return null;

    const handlePayClick = () => {
        setStep('pin');
    };

    const handlePinSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (verifyPin(pin)) {
            setStep('processing');
            setTimeout(() => {
                onSuccess();
                setStep('confirm');
                setPin('');
            }, 2000); // Simulate processing delay
        } else {
            setError('Invalid PIN');
        }
    };

    const handlePinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const val = e.target.value;
        if (/^\d*$/.test(val) && val.length <= 6) {
            setPin(val);
            setError('');
        }
    };

    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[100] backdrop-blur-sm p-4">
            <div className="bg-white w-full max-w-sm rounded-2xl overflow-hidden shadow-2xl animate-fade-in relative">
                
                {step !== 'processing' && (
                    <button 
                        onClick={onClose} 
                        className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 z-10"
                    >
                        <X size={24} />
                    </button>
                )}

                {step === 'confirm' && (
                    <div className="p-6 text-center">
                        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-600">
                            <Smartphone size={32} />
                        </div>
                        <h3 className="text-xl font-bold text-gray-800 mb-1">Payment Confirmation</h3>
                        <p className="text-gray-500 text-sm mb-6">Paying to <span className="font-semibold text-gray-800">{payee}</span></p>

                        <div className="text-4xl font-bold text-gray-900 mb-8">₹{amount.toLocaleString()}</div>

                        <div className="flex items-center justify-center gap-2 text-xs text-gray-400 mb-6">
                            <ShieldCheck size={14} className="text-green-500" />
                            Secure Payments by GPay/UPI
                        </div>

                        <button 
                            onClick={handlePayClick}
                            className="w-full bg-blue-600 text-white py-3 rounded-full font-bold text-lg hover:bg-blue-700 transition shadow-lg shadow-blue-200"
                        >
                            Proceed to Pay
                        </button>
                    </div>
                )}

                {step === 'pin' && (
                    <div className="p-6">
                        <div className="flex items-center gap-2 mb-6 justify-center">
                            <div className="bg-blue-600 p-1.5 rounded text-white">
                                <Lock size={14} />
                            </div>
                            <span className="font-bold text-gray-700">Enter UPI PIN</span>
                        </div>

                        <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 mb-6">
                            <div className="flex justify-between text-xs text-gray-500 mb-1">
                                <span>To: {payee}</span>
                                <span>₹{amount}</span>
                            </div>
                            <div className="text-right font-bold text-gray-800">State Bank of India ••9921</div>
                        </div>

                        <form onSubmit={handlePinSubmit}>
                            <div className="flex justify-center mb-2">
                                <input 
                                    type="password" 
                                    value={pin}
                                    onChange={handlePinChange}
                                    className="text-center text-3xl tracking-[1em] w-48 border-b-2 border-gray-300 focus:border-blue-600 outline-none pb-2 bg-transparent"
                                    placeholder="••••"
                                    autoFocus
                                />
                            </div>
                            {error && <p className="text-center text-red-500 text-xs mb-4">{error}</p>}
                            <p className="text-center text-xs text-gray-400 mb-8">Enter your 4 or 6 digit secure PIN</p>
                            
                            <button 
                                type="submit"
                                disabled={pin.length < 4}
                                className="w-full bg-gray-900 text-white py-3 rounded-xl font-bold hover:bg-black transition disabled:opacity-50"
                            >
                                Confirm
                            </button>
                        </form>
                    </div>
                )}

                {step === 'processing' && (
                    <div className="p-10 text-center flex flex-col items-center justify-center min-h-[350px]">
                        <div className="w-20 h-20 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mb-6"></div>
                        <h3 className="text-xl font-bold text-gray-800 animate-pulse">Processing Payment...</h3>
                        <p className="text-gray-500 text-sm mt-2">Do not close this window</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default PaymentModal;
