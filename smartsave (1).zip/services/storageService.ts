
import { Transaction, WalletState, TransactionType, Category, Debt, BankAccount, SavingsSprint, PaymentMode, Bill, Reward, User, MobilePlan } from '../types';

const TRANSACTIONS_KEY = 'smartsave_transactions';
const WALLET_KEY = 'smartsave_wallet';
const DEBTS_KEY = 'smartsave_debts';
const BANKS_KEY = 'smartsave_banks';
const SPRINTS_KEY = 'smartsave_sprints';
const BILLS_KEY = 'smartsave_bills';
const REWARDS_KEY = 'smartsave_rewards';
const CURRENT_USER_KEY = 'smartsave_current_user';
const USERS_LIST_KEY = 'smartsave_users_list';
const LAST_USER_PHONE_KEY = 'smartsave_last_user_phone';

// --- Auth & User Management ---

export const seedUsers = () => {
    const existingUsersStr = localStorage.getItem(USERS_LIST_KEY);
    let users: User[] = existingUsersStr ? JSON.parse(existingUsersStr) : [];

    const raniUser: User = { 
        phone: '9876543219', 
        name: 'Rani', 
        password: '123456', 
        role: 'user', 
        isLoggedIn: false, 
        joinedDate: new Date().toISOString() 
    };
    
    const adminUser: User = { 
        phone: 'pari', 
        name: 'Pari (Admin)', 
        password: 'parnika022', 
        role: 'admin', 
        isLoggedIn: false, 
        joinedDate: new Date().toISOString() 
    };

    // Update or Add Rani
    const raniIdx = users.findIndex(u => u.phone === '9876543219');
    if (raniIdx >= 0) {
        users[raniIdx] = { ...users[raniIdx], ...raniUser };
    } else {
        users = users.filter(u => u.name !== 'Rani' && u.phone !== 'rani');
        users.push(raniUser);
    }

    // Update or Add Admin
    const adminIdx = users.findIndex(u => u.phone === 'pari');
    if (adminIdx === -1) {
        users.push(adminUser);
    } else {
        users[adminIdx] = { ...users[adminIdx], ...adminUser };
    }

    localStorage.setItem(USERS_LIST_KEY, JSON.stringify(users));
};

export const registerUser = (user: User): { success: boolean, message: string } => {
    const usersStr = localStorage.getItem(USERS_LIST_KEY);
    const users: User[] = usersStr ? JSON.parse(usersStr) : [];

    if (users.find(u => u.phone === user.phone)) {
        return { success: false, message: 'User with this phone/ID already exists.' };
    }

    // New users default to 'user' role
    const newUser: User = { ...user, role: 'user', isLoggedIn: false, joinedDate: new Date().toISOString() };
    users.push(newUser);
    localStorage.setItem(USERS_LIST_KEY, JSON.stringify(users));
    
    return { success: true, message: 'Registration Successful! Please Login.' };
};

export const clearUserData = () => {
    // Reset all data keys to empty/zero for a fresh user experience
    localStorage.removeItem(BANKS_KEY);
    localStorage.removeItem(TRANSACTIONS_KEY);
    localStorage.removeItem(WALLET_KEY);
    localStorage.removeItem(DEBTS_KEY);
    localStorage.removeItem(BILLS_KEY);
    localStorage.removeItem(SPRINTS_KEY);
    localStorage.removeItem(REWARDS_KEY);
};

export const seedRaniData = () => {
    // 1. Banks
    const raniBanks: BankAccount[] = [
        { id: 'rb1', name: 'Primary Savings', holderName: 'Rani', bankName: 'HDFC Bank', balance: 45000, color: '#1d4ed8', accountNumber: 'HDFC-8899', ifsc: 'HDFC0001234' },
        { id: 'rb2', name: 'Salary Account', holderName: 'Rani', bankName: 'SBI', balance: 35000, color: '#0ea5e9', accountNumber: 'SBI-7721', ifsc: 'SBIN0004567' },
        { id: 'rcash', name: 'Cash Pouch', holderName: 'Rani', bankName: 'Cash', balance: 5000, color: '#10b981', accountNumber: 'N/A', ifsc: 'N/A' }
    ];
    localStorage.setItem(BANKS_KEY, JSON.stringify(raniBanks));

    // 2. Wallet
    const raniWallet: WalletState = {
        totalBalance: 85000,
        savings: 15000,
        healthFund: 5000,
        autoSaveEnabled: true,
        autoSaveSourceBankId: 'rb1', // Set default auto-save source
        lastAutoSaveDate: null,
        bankConnected: true,
        monthlyBudget: 30000, // Budget
        categoryBudgets: {
            [Category.FOOD]: 8000,
            [Category.TRAVEL]: 5000,
            [Category.BILLS]: 5000,
            [Category.OTHERS]: 12000
        }
    };
    localStorage.setItem(WALLET_KEY, JSON.stringify(raniWallet));

    // 3. Transactions (Rich History)
    const today = new Date();
    const raniTxs: Transaction[] = [
        { id: 'rt1', amount: 6500, category: Category.TRAVEL, description: 'Weekend Trip to Coorg (Resort + Travel)', date: new Date(today.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(), type: TransactionType.EXPENSE, source: 'Booking', paymentMode: 'UPI', bankAccountId: 'rb1' },
        { id: 'rt2', amount: 1200, category: Category.FOOD, description: 'Dinner at Truffles', date: new Date(today.getTime() - 1 * 24 * 60 * 60 * 1000).toISOString(), type: TransactionType.EXPENSE, source: 'GPay', paymentMode: 'UPI', bankAccountId: 'rb1' },
        { id: 'rt3', amount: 450, category: Category.TRAVEL, description: 'Uber to Office', date: today.toISOString(), type: TransactionType.EXPENSE, source: 'GPay', paymentMode: 'UPI', bankAccountId: 'rb2' },
        { id: 'rt4', amount: 2500, category: Category.FOOD, description: 'Monthly Groceries (D-Mart)', date: new Date(today.getTime() - 5 * 24 * 60 * 60 * 1000).toISOString(), type: TransactionType.EXPENSE, source: 'Manual', paymentMode: 'Credit Card', bankAccountId: 'rb1' },
        { id: 'rt5', amount: 1100, category: Category.BILLS, description: 'Bescom Electricity Bill', date: new Date(today.getTime() - 10 * 24 * 60 * 60 * 1000).toISOString(), type: TransactionType.EXPENSE, source: 'Bill Payment', paymentMode: 'UPI', bankAccountId: 'rb2' },
        { id: 'rt6', amount: 60000, category: Category.OTHERS, description: 'Salary Credited', date: new Date(today.getTime() - 15 * 24 * 60 * 60 * 1000).toISOString(), type: TransactionType.INCOME, source: 'Salary', paymentMode: 'UPI', bankAccountId: 'rb2' },
        { id: 'rt7', amount: 500, category: Category.ENTERTAINMENT, description: 'Netflix Subscription', date: new Date(today.getTime() - 12 * 24 * 60 * 60 * 1000).toISOString(), type: TransactionType.EXPENSE, source: 'Auto-Save', paymentMode: 'Debit Card', bankAccountId: 'rb1' },
        { id: 'rt8', amount: 200, category: Category.FOOD, description: 'Coffee Break', date: today.toISOString(), type: TransactionType.EXPENSE, source: 'Manual', paymentMode: 'Cash', bankAccountId: 'rcash' }
    ];
    localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(raniTxs));

    // 4. Debts
    localStorage.setItem(DEBTS_KEY, JSON.stringify([]));
    
    // 5. Bills (Full Suite for Demo)
    const raniBills: Bill[] = [
        { id: 'rbill1', type: 'Mobile', provider: 'Jio Prepaid', amount: 299, dueDate: new Date(today.getTime() + 5 * 24 * 60 * 60 * 1000).toISOString(), isAutoPay: false, identifier: '9876543219' },
        { id: 'rbill2', type: 'Gas Cylinder', provider: 'Indane Gas', amount: 1150, lastPaid: new Date(today.getTime() - 40 * 24 * 60 * 60 * 1000).toISOString(), isAutoPay: false, identifier: 'Customer ID: 887766' },
        { id: 'rbill3', type: 'Electricity', provider: 'Bescom', amount: 1200, dueDate: new Date(today.getTime() + 10 * 24 * 60 * 60 * 1000).toISOString(), isAutoPay: false, identifier: 'RR No: 991122' },
        { id: 'rbill4', type: 'Fastag', provider: 'ICICI Fastag', amount: 500, lastPaid: new Date(today.getTime() - 15 * 24 * 60 * 60 * 1000).toISOString(), isAutoPay: false, identifier: 'KA-01-MJ-1234' },
        { id: 'rbill5', type: 'Cable TV', provider: 'Tata Play', amount: 450, dueDate: new Date(today.getTime() + 2 * 24 * 60 * 60 * 1000).toISOString(), isAutoPay: true, identifier: 'Sub ID: 1122334455' },
        { id: 'rbill6', type: 'Internet', provider: 'ACT Fibernet', amount: 1049, dueDate: new Date(today.getTime() + 20 * 24 * 60 * 60 * 1000).toISOString(), isAutoPay: true, identifier: 'Acc: 887711' }
    ];
    localStorage.setItem(BILLS_KEY, JSON.stringify(raniBills));

    // 6. Sprints
    localStorage.setItem(SPRINTS_KEY, JSON.stringify([]));
};

const initializeUserSession = (phone: string) => {
    const lastUser = localStorage.getItem(LAST_USER_PHONE_KEY);
    
    // If the user changed, or if it is a specific demo user
    if (lastUser !== phone) {
        if (phone === '9876543219') {
            seedRaniData();
        } else if (phone === 'pari') {
            // Admin - Do nothing to data
        } else {
            // New user or different user - Clear data to start fresh (Zero State)
            clearUserData();
        }
        localStorage.setItem(LAST_USER_PHONE_KEY, phone);
    } else {
        // Same user logging back in.
        // If it's Rani, ensure data is consistent? No, let persistence happen.
        // But if data is missing (maybe cleared manually), restore it for Rani.
        if (phone === '9876543219' && !localStorage.getItem(BANKS_KEY)) {
            seedRaniData();
        }
        // If other user and no data, they stay with 0 data.
    }
}

export const loginUser = (phone: string, password: string): { success: boolean, role?: string } => {
    seedUsers(); // Ensure defaults exist and get latest list
    const usersStr = localStorage.getItem(USERS_LIST_KEY);
    const users: User[] = usersStr ? JSON.parse(usersStr) : [];

    const user = users.find(u => u.phone === phone && u.password === password);
    
    if (user) {
        initializeUserSession(user.phone);

        const sessionUser = { ...user, isLoggedIn: true };
        localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(sessionUser));
        return { success: true, role: user.role };
    }
    return { success: false };
};

export const logoutUser = () => {
    localStorage.removeItem(CURRENT_USER_KEY);
};

export const getCurrentUser = (): User | null => {
    const data = localStorage.getItem(CURRENT_USER_KEY);
    return data ? JSON.parse(data) : null;
};

export const getAllUsers = (): User[] => {
    const data = localStorage.getItem(USERS_LIST_KEY);
    return data ? JSON.parse(data) : [];
};

export const verifyAppPassword = (password: string): boolean => {
    const user = getCurrentUser();
    // Verify against the logged-in user's stored password
    return user?.password === password;
};

export const verifyPin = (pin: string): boolean => {
    return pin.length === 4 || pin.length === 6;
};

// --- Bank Management ---

const DEFAULT_BANKS: BankAccount[] = []; // Empty for new users

export const getBankAccounts = (): BankAccount[] => {
  const data = localStorage.getItem(BANKS_KEY);
  return data ? JSON.parse(data) : DEFAULT_BANKS;
};

export const updateBankAccount = (id: string, newBalance: number): void => {
  const banks = getBankAccounts();
  const updated = banks.map(b => b.id === id ? { ...b, balance: newBalance } : b);
  localStorage.setItem(BANKS_KEY, JSON.stringify(updated));
  recalculateTotalWallet();
};

export const addBankAccount = (bank: BankAccount): void => {
    const banks = getBankAccounts();
    const updated = [...banks, bank];
    localStorage.setItem(BANKS_KEY, JSON.stringify(updated));
    recalculateTotalWallet();
};

// --- Transactions ---

export const getTransactions = (): Transaction[] => {
  const data = localStorage.getItem(TRANSACTIONS_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveTransaction = (transaction: Transaction): void => {
  const transactions = getTransactions();
  const updated = [transaction, ...transactions];
  localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(updated));
  
  // Update specific bank balance if linked
  if (transaction.bankAccountId) {
    const banks = getBankAccounts();
    const bank = banks.find(b => b.id === transaction.bankAccountId);
    if (bank) {
      let newBalance = bank.balance;
      if (transaction.type === TransactionType.EXPENSE) {
        newBalance -= transaction.amount;
      } else {
        newBalance += transaction.amount;
      }
      updateBankAccount(bank.id, newBalance);
    }
  } else {
    const wallet = getWallet();
    if (transaction.type === TransactionType.EXPENSE) {
       wallet.totalBalance -= transaction.amount;
    } else {
       wallet.totalBalance += transaction.amount;
    }
    saveWallet(wallet);
  }

  // Check budget after expense
  if (transaction.type === TransactionType.EXPENSE) {
      checkBudgetAndReward();
  }
};

// --- Debt Management ---

export const getDebts = (): Debt[] => {
  const data = localStorage.getItem(DEBTS_KEY);
  return data ? JSON.parse(data) : [];
};

export const addDebt = (debt: Debt): void => {
  const debts = getDebts();
  const updated = [debt, ...debts];
  localStorage.setItem(DEBTS_KEY, JSON.stringify(updated));
};

export const markDebtPaid = (id: string): void => {
  const debts = getDebts();
  const updated = debts.map(d => d.id === id ? { ...d, isPaid: true } : d);
  localStorage.setItem(DEBTS_KEY, JSON.stringify(updated));
};

// --- Agile Sprints (Savings Goals) ---

export const getSprints = (): SavingsSprint[] => {
  const data = localStorage.getItem(SPRINTS_KEY);
  return data ? JSON.parse(data) : [];
};

export const createSprint = (sprint: SavingsSprint): void => {
  const sprints = getSprints();
  localStorage.setItem(SPRINTS_KEY, JSON.stringify([...sprints, sprint]));
};

export const updateSprintProgress = (id: string, amountToAdd: number): void => {
  const sprints = getSprints();
  const updated = sprints.map(s => {
    if (s.id === id) {
      const newAmount = s.currentAmount + amountToAdd;
      const status = newAmount >= s.targetAmount ? 'Completed' : 'Active';
      return { ...s, currentAmount: newAmount, status };
    }
    return s;
  });
  localStorage.setItem(SPRINTS_KEY, JSON.stringify(updated));
  
  // Also update total savings in wallet
  const wallet = getWallet();
  wallet.savings += amountToAdd;
  saveWallet(wallet);
};

// --- Bills & Cylinder Tracking ---

const DEFAULT_BILLS: Bill[] = []; // Empty for new users

export const getBills = (): Bill[] => {
    const data = localStorage.getItem(BILLS_KEY);
    return data ? JSON.parse(data) : DEFAULT_BILLS;
};

export const saveBills = (bills: Bill[]) => {
    localStorage.setItem(BILLS_KEY, JSON.stringify(bills));
};

export const payBill = (billId: string, amount: number) => {
    const bills = getBills();
    const updated = bills.map(b => b.id === billId ? { ...b, lastPaid: new Date().toISOString(), dueDate: new Date(Date.now() + 2592000000).toISOString() } : b); // Add 30 days to due date
    saveBills(updated);

    // Record Transaction
    const banks = getBankAccounts();
    const sourceBank = banks.find(b => b.balance >= amount) || banks[0];
    
    if (sourceBank) {
        saveTransaction({
            id: `bill-${Date.now()}`,
            amount,
            category: Category.BILLS,
            description: `Paid Bill: ${bills.find(b => b.id === billId)?.type}`,
            date: new Date().toISOString(),
            type: TransactionType.EXPENSE,
            source: 'Bill Payment',
            bankAccountId: sourceBank.id,
            paymentMode: 'UPI'
        });
    }
};

export const getMobilePlans = (): MobilePlan[] => {
    return [
        { id: 'p1', price: 299, data: '1.5GB/day', validity: '28 Days', calls: 'Unlimited', category: 'Daily Plans', description: 'Bestseller' },
        { id: 'p2', price: 719, data: '2GB/day', validity: '84 Days', calls: 'Unlimited', category: 'Daily Plans', description: 'Value Pack' },
        { id: 'p3', price: 155, data: '1GB Total', validity: '28 Days', calls: 'Unlimited', category: 'Monthly Plans', description: 'Entry Pack' },
        { id: 'p4', price: 2999, data: '2.5GB/day', validity: '365 Days', calls: 'Unlimited', category: 'Yearly Plans', description: 'Annual 5G' },
        { id: 'p5', price: 19, data: '1GB', validity: 'Active Plan', calls: 'N/A', category: 'Top-up', description: 'Data Booster' },
        { id: 'p6', price: 209, data: '1GB/day', validity: '28 Days', calls: 'Unlimited', category: 'Daily Plans', description: 'Standard Pack' },
        { id: 'p7', price: 666, data: '1.5GB/day', validity: '84 Days', calls: 'Unlimited', category: 'Daily Plans', description: 'Long Term' },
        { id: 'p8', price: 395, data: '6GB Total', validity: '84 Days', calls: 'Unlimited', category: 'Monthly Plans', description: 'Value 3 Month' }
    ];
};

// --- Rewards ---

export const getRewards = (): Reward[] => {
    const data = localStorage.getItem(REWARDS_KEY);
    return data ? JSON.parse(data) : [];
};

export const addReward = (reward: Reward) => {
    const rewards = getRewards();
    localStorage.setItem(REWARDS_KEY, JSON.stringify([reward, ...rewards]));
};

export const checkBudgetAndReward = () => {
    const wallet = getWallet();
    const txs = getTransactions();
    const currentMonth = new Date().getMonth();
    
    const expenses = txs
      .filter(t => t.type === TransactionType.EXPENSE && new Date(t.date).getMonth() === currentMonth)
      .reduce((sum, t) => sum + t.amount, 0);

    if (expenses < wallet.monthlyBudget && Math.random() > 0.8) {
        const rewards = getRewards();
        const today = new Date().toDateString();
        if (!rewards.find(r => new Date(r.dateEarned).toDateString() === today)) {
             addReward({
                 id: `rew-${Date.now()}`,
                 title: 'Budget Keeper Award',
                 value: `₹${Math.floor(Math.random() * 50) + 10} Wallet Cash`,
                 dateEarned: new Date().toISOString(),
                 isRedeemed: false
             });
        }
    }
};

// --- Wallet Management ---

const DEFAULT_WALLET: WalletState = {
  totalBalance: 0,
  savings: 0,
  healthFund: 0,
  autoSaveEnabled: false,
  autoSaveSourceBankId: undefined,
  lastAutoSaveDate: null,
  bankConnected: false,
  monthlyBudget: 0,
  categoryBudgets: {}
};

export const getWallet = (): WalletState => {
  const data = localStorage.getItem(WALLET_KEY);
  let wallet = data ? JSON.parse(data) : DEFAULT_WALLET;
  
  const banks = getBankAccounts();
  const totalBankBalance = banks.reduce((sum, b) => sum + b.balance, 0);
  
  // Only sync balance if wallet thinks it's 0 but banks have money (initial load sync)
  if (wallet.totalBalance === 0 && totalBankBalance > 0) {
      wallet.totalBalance = totalBankBalance;
  }
  
  return wallet;
};

export const recalculateTotalWallet = () => {
    const banks = getBankAccounts();
    const total = banks.reduce((sum, b) => sum + b.balance, 0);
    const wallet = getWallet();
    wallet.totalBalance = total;
    saveWallet(wallet);
}

export const saveWallet = (wallet: WalletState): void => {
  localStorage.setItem(WALLET_KEY, JSON.stringify(wallet));
};

export const processSalary = (salaryAmount: number, bankId: string, splits: Record<string, number>) => {
    const salaryTx: Transaction = {
        id: `sal-${Date.now()}`,
        amount: salaryAmount,
        category: Category.OTHERS,
        description: 'Salary Credited',
        date: new Date().toISOString(),
        type: TransactionType.INCOME,
        source: 'Salary',
        paymentMode: 'UPI',
        bankAccountId: bankId
    };
    saveTransaction(salaryTx);

    const savingsAmount = splits['Savings'] || 0;
    if (savingsAmount > 0) {
        saveTransaction({
            id: `save-${Date.now()}`,
            amount: savingsAmount,
            category: Category.OTHERS,
            description: 'Auto-Transfer to Savings Vault',
            date: new Date().toISOString(),
            type: TransactionType.EXPENSE,
            source: 'Auto-Save',
            bankAccountId: bankId
        });

        const wallet = getWallet();
        wallet.savings += savingsAmount;
        wallet.monthlyBudget = salaryAmount - savingsAmount;
        wallet.categoryBudgets = {
            [Category.FOOD]: splits[Category.FOOD] || 0,
            [Category.TRAVEL]: splits[Category.TRAVEL] || 0,
            [Category.BILLS]: splits[Category.BILLS] || 0,
            [Category.OTHERS]: splits[Category.OTHERS] || 0,
            [Category.HEALTH]: splits[Category.HEALTH] || 0,
        };
        saveWallet(wallet);
    }
};

export const processAutoSave = (): { processed: boolean, message: string } => {
  const wallet = getWallet();
  if (!wallet.autoSaveEnabled) return { processed: false, message: '' };

  const today = new Date().toDateString();
  
  if (wallet.lastAutoSaveDate !== today) {
    const banks = getBankAccounts();
    
    let fundingBank: BankAccount | undefined;

    // Use specific bank if selected
    if (wallet.autoSaveSourceBankId) {
        fundingBank = banks.find(b => b.id === wallet.autoSaveSourceBankId);
    }
    
    if (fundingBank && fundingBank.balance >= 10) {
      updateBankAccount(fundingBank.id, fundingBank.balance - 10);
      
      wallet.savings += 10;
      wallet.lastAutoSaveDate = today;
      saveWallet(wallet);
      
      const autoSaveTx: Transaction = {
        id: Date.now().toString(),
        amount: 10,
        category: Category.OTHERS,
        description: `Daily Auto-Save (via ${fundingBank.bankName})`,
        date: new Date().toISOString(),
        type: TransactionType.EXPENSE,
        source: 'Auto-Save',
        bankAccountId: fundingBank.id
      };
      
      const transactions = getTransactions();
      localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify([autoSaveTx, ...transactions]));

      const sprints = getSprints();
      const activeSprint = sprints.find(s => s.status === 'Active');
      if (activeSprint) {
          updateSprintProgress(activeSprint.id, 10);
      }

      return { processed: true, message: `Agile Save: ₹10 deducted from ${fundingBank.bankName}` };
    } else {
        return { processed: false, message: '' };
    }
  }
  return { processed: false, message: '' };
};

export const connectBank = () => {
  const wallet = getWallet();
  wallet.bankConnected = true;
  saveWallet(wallet);
  // Do NOT auto-seed default banks for new users as per request
  return wallet;
};

const detectCategory = (text: string): Category => {
  const t = text.toLowerCase();
  if (t.includes('swiggy') || t.includes('zomato') || t.includes('mcdonald') || t.includes('pizza')) return Category.FOOD;
  if (t.includes('uber') || t.includes('ola') || t.includes('rapido') || t.includes('fuel') || t.includes('shell')) return Category.TRAVEL;
  if (t.includes('netflix') || t.includes('spotify') || t.includes('cinema')) return Category.ENTERTAINMENT;
  if (t.includes('amazon') || t.includes('flipkart') || t.includes('myntra')) return Category.SHOPPING;
  if (t.includes('pharmacy') || t.includes('hospital') || t.includes('med')) return Category.HEALTH;
  return Category.OTHERS;
};

export const syncUPITransactions = (): { count: number, transactions: Transaction[] } => {
  const potentialMerchants = [
    { desc: 'Paid to Swiggy', amount: 340 },
    { desc: 'Uber Ride', amount: 150 },
    { desc: 'Starbucks Coffee', amount: 250 },
    { desc: 'Shell Petrol Pump', amount: 500 },
    { desc: 'Netflix Subscription', amount: 199 },
    { desc: 'Amazon Purchase', amount: 890 },
    { desc: 'Apollo Pharmacy', amount: 450 }
  ];

  const banks = getBankAccounts();
  const spendingBank = banks[0]; 

  if (!spendingBank) return { count: 0, transactions: [] };

  const count = Math.floor(Math.random() * 3) + 1;
  const newTxs: Transaction[] = [];

  for (let i = 0; i < count; i++) {
    const merchant = potentialMerchants[Math.floor(Math.random() * potentialMerchants.length)];
    const tx: Transaction = {
      id: `upi-${Date.now()}-${i}`,
      amount: merchant.amount,
      category: detectCategory(merchant.desc),
      description: merchant.desc,
      date: new Date().toISOString(),
      type: TransactionType.EXPENSE,
      source: Math.random() > 0.5 ? 'GPay' : 'PhonePe',
      paymentMode: 'UPI',
      bankAccountId: spendingBank.id
    };
    newTxs.push(tx);
    saveTransaction(tx);
  }

  return { count, transactions: newTxs };
};

export const seedData = () => {
  seedUsers();
  // We NO LONGER auto-seed random financial data.
  // Data is only seeded if the specific Rani user logs in.
};
