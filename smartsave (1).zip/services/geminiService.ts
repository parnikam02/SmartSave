
import { GoogleGenAI } from "@google/genai";
import { Transaction, WalletState, TravelPlan } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getFinancialAdvice = async (transactions: Transaction[], wallet: WalletState): Promise<string> => {
  try {
    const recentTransactions = transactions.slice(0, 30); 
    
    const prompt = `
      You are the backend AI engine for "SmartSave", a finance app. 
      Analyze the user's transaction history and provide a JSON-like structured response (but in valid Markdown) with tailored money-saving tips and investment ideas.

      User Stats:
      - Current Balance: ₹${wallet.totalBalance}
      - Total Savings: ₹${wallet.savings}
      - Auto-Save Enabled: ${wallet.autoSaveEnabled}
      - Health Fund: ₹${wallet.healthFund}
      
      Recent Transactions (JSON):
      ${JSON.stringify(recentTransactions)}

      Task:
      1. **Spending Analysis**: Identify the top 2 spending categories.
      2. **Save Money Tips**: Provide 3 specific, actionable tips.
      3. **Health & Insurance**: Suggest one health insurance policy type if they spend a lot on medical.
      4. **Investment Ideas**: Mutual Funds (SIPs) and Gold.
      5. **Start Today**: Give 1 or 2 immediate actions they can take TODAY to save money.
      
      Format your response in Markdown with these headers:
      ## 📊 Spending Analysis
      ## 💡 Smart Saving Tips
      ## 🏥 Health & Protection
      ## 📈 Investment Opportunities
      ## 🚀 Start Saving Today
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Unable to generate advice at the moment.";
  } catch (error) {
    console.error("Error fetching AI advice:", error);
    return "Sorry, I couldn't connect to the financial brain right now. Please try again later.";
  }
};

export const getLifestylePlan = async (type: 'relax' | 'temple' | 'dining', budget: number, transportPreference?: string): Promise<TravelPlan> => {
    try {
        const prompt = `
            Create a realistic, single option plan for a user in India with a budget of roughly ₹${budget}.
            Type of Plan: ${type} (Relax = Weekend getaway nearby, Temple = Famous temple visit like Tirupati, Dining = New unique restaurant).
            ${transportPreference ? `Preferred Transport Mode: ${transportPreference}. Calculate costs (fuel/tolls or tickets) specifically for this mode.` : ''}
            
            Return ONLY a valid JSON object with no markdown formatting. The JSON structure should be:
            {
                "destination": "Name of Place",
                "description": "Short description of why to go there and what to do (max 2 sentences).",
                "totalCost": number (total estimated cost),
                "transportMode": "${transportPreference || 'Car'}", 
                "breakdown": {
                    "tickets": number (cost of tickets/fuel),
                    "tolls": number (if car, estimate fastag cost, else 0),
                    "food": number,
                    "accommodation": number,
                    "misc": number
                },
                "recommendationType": "${type === 'relax' ? 'Relax' : type === 'temple' ? 'Devotional' : 'Dining'}"
            }
        `;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json"
            }
        });

        const text = response.text;
        if (!text) throw new Error("No response");
        
        return JSON.parse(text) as TravelPlan;

    } catch (error) {
        console.error("AI Plan Error", error);
        // Fallback mock plan
        return {
            destination: type === 'temple' ? "Tirupati Balaji" : type === 'dining' ? "Barbeque Nation" : "Nandi Hills",
            description: "A popular destination to unwind and seek blessings.",
            totalCost: 3500,
            transportMode: (transportPreference as any) || "Car",
            breakdown: { tickets: 1200, tolls: 150, food: 1000, accommodation: 1000, misc: 150 },
            recommendationType: type === 'temple' ? 'Devotional' : type === 'dining' ? 'Dining' : 'Relax'
        };
    }
}
