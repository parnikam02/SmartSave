
import React, { useState } from 'react';
import { getLifestylePlan } from '../services/geminiService';
import { saveTransaction, getWallet } from '../services/storageService';
import { TravelPlan, Category, TransactionType } from '../types';
import { Plane, Utensils, Church, Loader2, Car, HeartPulse, ShieldCheck, MapPin, Tag, Bus, Train } from 'lucide-react';
import PaymentModal from '../components/PaymentModal';

const Lifestyle: React.FC = () => {
    const [loading, setLoading] = useState<'relax' | 'temple' | 'dining' | null>(null);
    const [plan, setPlan] = useState<TravelPlan | null>(null);
    const [booked, setBooked] = useState(false);
    const [transportMode, setTransportMode] = useState<string>('Car');
    
    // Payment Modal State
    const [showPaymentModal, setShowPaymentModal] = useState(false);

    const generatePlan = async (type: 'relax' | 'temple' | 'dining') => {
        setLoading(type);
        setPlan(null);
        setBooked(false);
        // Simulate budget based on type
        const budget = type === 'dining' ? 2000 : 5000;
        const result = await getLifestylePlan(type, budget, transportMode);
        setPlan(result);
        setLoading(null);
    };

    const handleBookClick = () => {
        if (plan) {
            setShowPaymentModal(true);
        }
    };

    const handlePaymentSuccess = () => {
        if (!plan) return;
        
        // Save the main expense
        saveTransaction({
            id: `trip-${Date.now()}`,
            amount: plan.totalCost,
            category: plan.recommendationType === 'Dining' ? Category.FOOD : Category.TRAVEL,
            description: `Booking: ${plan.destination} (${plan.transportMode})`,
            date: new Date().toISOString(),
            type: TransactionType.EXPENSE,
            source: 'Booking',
            paymentMode: 'UPI'
        });

        // If car, check if fastag needs recharge (simulated logic)
        if (plan.transportMode === 'Car' && plan.breakdown.tolls && plan.breakdown.tolls > 0) {
             // We can assume we deduct from fastag balance or just note it
        }

        setShowPaymentModal(false);
        setBooked(true);
    };

    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h2 className="text-2xl font-bold text-gray-800">Lifestyle & Travel Planner</h2>
                    <p className="text-gray-500 text-sm">Relax, explore, and stay healthy with AI-curated plans.</p>
                </div>
            </div>

            {/* Health & Insurance Section */}
            <div className="bg-gradient-to-r from-teal-500 to-emerald-600 rounded-xl p-6 text-white shadow-lg flex flex-col md:flex-row items-center justify-between gap-6">
                 <div className="flex items-center gap-4">
                     <div className="bg-white/20 p-3 rounded-full">
                         <HeartPulse size={32} />
                     </div>
                     <div>
                         <h3 className="font-bold text-lg flex items-center gap-2"><ShieldCheck size={20}/> Health & Insurance Fund</h3>
                         <p className="text-teal-100 text-sm max-w-lg mt-1">
                             Allocating money for health is crucial. We recommend saving ₹2,000/month specifically for medical emergencies or insurance premiums.
                         </p>
                     </div>
                 </div>
                 <button className="bg-white text-teal-700 px-6 py-2 rounded-full font-bold hover:bg-teal-50 transition whitespace-nowrap">
                     View Policies
                 </button>
            </div>
            
            {/* Transport Preferences */}
            <div className="bg-white p-4 rounded-xl border border-gray-200">
                <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                    <MapPin size={16} /> Choose Preferred Transport Mode
                </h3>
                <div className="flex gap-2">
                    {['Car', 'Bus', 'Train', 'Flight'].map(mode => (
                        <button
                            key={mode}
                            onClick={() => setTransportMode(mode)}
                            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition border ${
                                transportMode === mode 
                                ? 'bg-indigo-50 border-indigo-200 text-indigo-700' 
                                : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
                            }`}
                        >
                            {mode === 'Car' && <Car size={14} />}
                            {mode === 'Bus' && <Bus size={14} />}
                            {mode === 'Train' && <Train size={14} />}
                            {mode === 'Flight' && <Plane size={14} />}
                            {mode}
                        </button>
                    ))}
                </div>
            </div>

            {/* Planning Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                {/* Weekend Relax */}
                <div onClick={() => generatePlan('relax')} className="cursor-pointer bg-white p-6 rounded-xl border border-gray-200 hover:border-indigo-400 hover:shadow-md transition group">
                    <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center text-blue-600 mb-4 group-hover:scale-110 transition">
                        <Car size={24} />
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2">Weekend Getaway</h3>
                    <p className="text-sm text-gray-500 mb-4">Stress-free nearby places to relax. Optimized for {transportMode}.</p>
                    <button disabled={loading === 'relax'} className="text-blue-600 font-semibold text-sm flex items-center gap-2">
                        {loading === 'relax' ? <Loader2 className="animate-spin" size={16}/> : 'Plan Trip'}
                    </button>
                </div>

                {/* Temple Visit */}
                <div onClick={() => generatePlan('temple')} className="cursor-pointer bg-white p-6 rounded-xl border border-gray-200 hover:border-orange-400 hover:shadow-md transition group">
                    <div className="bg-orange-100 w-12 h-12 rounded-full flex items-center justify-center text-orange-600 mb-4 group-hover:scale-110 transition">
                        <Church size={24} />
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2">Temple Visit</h3>
                    <p className="text-sm text-gray-500 mb-4">Divine trips to Tirupati or nearby temples every 3 months.</p>
                    <button disabled={loading === 'temple'} className="text-orange-600 font-semibold text-sm flex items-center gap-2">
                        {loading === 'temple' ? <Loader2 className="animate-spin" size={16}/> : 'Plan Visit'}
                    </button>
                </div>

                {/* Dining Out */}
                <div onClick={() => generatePlan('dining')} className="cursor-pointer bg-white p-6 rounded-xl border border-gray-200 hover:border-pink-400 hover:shadow-md transition group">
                    <div className="bg-pink-100 w-12 h-12 rounded-full flex items-center justify-center text-pink-600 mb-4 group-hover:scale-110 transition">
                        <Utensils size={24} />
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2">New Eats</h3>
                    <p className="text-sm text-gray-500 mb-4">Discover new food spots fitting your budget.</p>
                    <button disabled={loading === 'dining'} className="text-pink-600 font-semibold text-sm flex items-center gap-2">
                        {loading === 'dining' ? <Loader2 className="animate-spin" size={16}/> : 'Find Restaurant'}
                    </button>
                </div>
            </div>

            {/* Generated Plan View */}
            {plan && (
                <div className="bg-white rounded-xl shadow-lg border border-indigo-100 overflow-hidden animate-fade-in">
                    <div className="bg-indigo-600 p-4 text-white flex justify-between items-center">
                        <h3 className="font-bold flex items-center gap-2">
                            <Plane size={20} /> Suggested Plan: {plan.destination}
                        </h3>
                        <span className="bg-white/20 px-3 py-1 rounded text-sm">Est. Cost: ₹{plan.totalCost}</span>
                    </div>
                    
                    <div className="p-6">
                        <p className="text-gray-600 mb-6 italic">"{plan.description}"</p>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
                            <div>
                                <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2"><Tag size={18}/> Cost Breakdown</h4>
                                <ul className="space-y-2 text-sm text-gray-600">
                                    <li className="flex justify-between">
                                        <span>Transport ({plan.transportMode}):</span>
                                        <span className="font-medium">₹{plan.breakdown.tickets}</span>
                                    </li>
                                    {plan.transportMode === 'Car' && (
                                        <li className="flex justify-between text-orange-600 bg-orange-50 px-2 rounded">
                                            <span>Fastag / Tolls:</span>
                                            <span className="font-medium">₹{plan.breakdown.tolls}</span>
                                        </li>
                                    )}
                                    <li className="flex justify-between">
                                        <span>Food & Dining:</span>
                                        <span className="font-medium">₹{plan.breakdown.food}</span>
                                    </li>
                                    <li className="flex justify-between">
                                        <span>Accommodation:</span>
                                        <span className="font-medium">₹{plan.breakdown.accommodation}</span>
                                    </li>
                                </ul>
                            </div>

                            <div className="bg-gray-50 p-4 rounded-lg">
                                <h4 className="font-semibold text-gray-800 mb-2 flex items-center gap-2"><MapPin size={18} /> Travel Logistics</h4>
                                <p className="text-sm text-gray-600 mb-2">
                                    <strong>Mode:</strong> {plan.transportMode}
                                </p>
                                {plan.transportMode === 'Car' && (
                                    <p className="text-xs text-gray-500 mb-4">
                                        Tip: Ensure your Fastag is recharged with at least ₹{plan.breakdown.tolls} before leaving to avoid double toll charges.
                                    </p>
                                )}
                                {plan.transportMode === 'Bus' || plan.transportMode === 'Train' || plan.transportMode === 'Flight' ? (
                                    <p className="text-xs text-gray-500 mb-4">
                                        Prices are estimates. Book early for best rates.
                                    </p>
                                ) : null}
                            </div>
                        </div>

                        {booked ? (
                            <div className="bg-green-100 text-green-700 p-3 rounded-lg text-center font-medium">
                                Booking Confirmed! Money deducted from wallet. Enjoy your trip!
                            </div>
                        ) : (
                            <button 
                                onClick={handleBookClick}
                                className="w-full bg-indigo-600 text-white py-3 rounded-lg font-bold hover:bg-indigo-700 transition"
                            >
                                Book Experience & Pay ₹{plan.totalCost}
                            </button>
                        )}
                    </div>
                </div>
            )}

            {/* Secure Payment Modal */}
            <PaymentModal 
                isOpen={showPaymentModal}
                amount={plan?.totalCost || 0}
                payee={plan?.destination || 'Travel Partner'}
                onClose={() => setShowPaymentModal(false)}
                onSuccess={handlePaymentSuccess}
            />
        </div>
    );
};

export default Lifestyle;
