
import React, { useEffect, useState } from 'react';
import { getBills, payBill, getMobilePlans } from '../services/storageService';
import { Bill, MobilePlan } from '../types';
import { Flame, Zap, Smartphone, Car, CheckCircle, AlertTriangle, RefreshCw, Tv, Wifi, Router, X, IndianRupee, Signal } from 'lucide-react';
import PaymentModal from '../components/PaymentModal';

const Bills: React.FC = () => {
    const [bills, setBills] = useState<Bill[]>([]);
    
    // Payment Modal State
    const [payeeName, setPayeeName] = useState('');
    const [payAmount, setPayAmount] = useState(0);
    const [showPaymentModal, setShowPaymentModal] = useState(false);
    const [pendingBillId, setPendingBillId] = useState<string | null>(null);

    // Custom Amount Input State (For Fastag)
    const [showAmountModal, setShowAmountModal] = useState(false);
    const [customAmount, setCustomAmount] = useState('');
    const [amountError, setAmountError] = useState('');

    // Mobile Plan Modal State
    const [showRechargeModal, setShowRechargeModal] = useState(false);
    const [mobilePlans, setMobilePlans] = useState<MobilePlan[]>([]);
    const [selectedPlanCategory, setSelectedPlanCategory] = useState<'Daily Plans' | 'Monthly Plans' | 'Yearly Plans' | 'Top-up'>('Daily Plans');
    const [rechargeNumber, setRechargeNumber] = useState('');

    useEffect(() => {
        setBills(getBills());
        setMobilePlans(getMobilePlans());
    }, []);

    const handlePayClick = (bill: Bill) => {
        setPayeeName(`${bill.provider} (${bill.type})`);
        setPayAmount(bill.amount);
        setPendingBillId(bill.id);
        setShowPaymentModal(true);
    };

    const handleQuickAction = (type: string) => {
        if (type === 'Mobile') {
            setShowRechargeModal(true);
        } else if (type === 'Fastag') {
            setPayeeName('ICICI Fastag Recharge');
            setCustomAmount('');
            setAmountError('');
            setShowAmountModal(true);
        } else {
            // Generic Action
            setPayeeName(type === 'Internet' ? 'Broadband Bill' : 'DTH Recharge');
            // Check for existing unpaid bill
            const existing = bills.find(b => b.type === type && (!b.lastPaid || new Date(b.lastPaid).getMonth() !== new Date().getMonth()));
            if (existing) {
                handlePayClick(existing);
            } else {
                setPayAmount(500); // Default placeholder if no bill exists
                setShowPaymentModal(true);
            }
        }
    };

    const handleCustomAmountSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const amt = parseFloat(customAmount);
        if (isNaN(amt) || amt < 100) {
            setAmountError('Minimum recharge amount is ₹100');
            return;
        }
        setPayAmount(amt);
        setShowAmountModal(false);
        setPendingBillId(null);
        setShowPaymentModal(true);
    };

    const handlePlanSelect = (plan: MobilePlan) => {
        setPayeeName(`Mobile Recharge - ${rechargeNumber || 'Self'}`);
        setPayAmount(plan.price);
        setShowRechargeModal(false);
        setPendingBillId(null); // Ad-hoc payment
        setShowPaymentModal(true);
    };

    const handlePaymentSuccess = () => {
        if (pendingBillId) {
            payBill(pendingBillId, payAmount);
            setBills(getBills()); // Reload
        }
        setShowPaymentModal(false);
        setPendingBillId(null);
    };

    const getIcon = (type: string) => {
        switch(type) {
            case 'Gas Cylinder': return <Flame className="text-orange-500" />;
            case 'Electricity': return <Zap className="text-yellow-500" />;
            case 'Mobile': return <Smartphone className="text-blue-500" />;
            case 'Fastag': return <Car className="text-purple-500" />;
            case 'Cable TV': case 'DTH': return <Tv className="text-pink-500" />;
            case 'Internet': return <Wifi className="text-cyan-500" />;
            default: return <RefreshCw className="text-gray-500" />;
        }
    }

    const filteredPlans = mobilePlans.filter(p => p.category === selectedPlanCategory);

    return (
        <div className="space-y-8">
            <h2 className="text-2xl font-bold text-gray-800">Bills & Utility Hub</h2>

            {/* Quick Recharge Grid */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-4">Quick Recharge & Pay</h3>
                <div className="grid grid-cols-4 md:grid-cols-6 gap-4">
                    <button onClick={() => handleQuickAction('Mobile')} className="flex flex-col items-center gap-2 group">
                        <div className="bg-blue-50 p-4 rounded-full group-hover:bg-blue-100 transition text-blue-600">
                            <Smartphone size={24} />
                        </div>
                        <span className="text-xs font-medium text-gray-600">Mobile</span>
                    </button>
                    <button onClick={() => handleQuickAction('Fastag')} className="flex flex-col items-center gap-2 group">
                        <div className="bg-purple-50 p-4 rounded-full group-hover:bg-purple-100 transition text-purple-600">
                            <Car size={24} />
                        </div>
                        <span className="text-xs font-medium text-gray-600">Fastag</span>
                    </button>
                    <button onClick={() => handleQuickAction('Cable TV')} className="flex flex-col items-center gap-2 group">
                        <div className="bg-pink-50 p-4 rounded-full group-hover:bg-pink-100 transition text-pink-600">
                            <Tv size={24} />
                        </div>
                        <span className="text-xs font-medium text-gray-600">DTH / Cable</span>
                    </button>
                    <button onClick={() => handleQuickAction('Internet')} className="flex flex-col items-center gap-2 group">
                        <div className="bg-cyan-50 p-4 rounded-full group-hover:bg-cyan-100 transition text-cyan-600">
                            <Wifi size={24} />
                        </div>
                        <span className="text-xs font-medium text-gray-600">Broadband</span>
                    </button>
                    <button className="flex flex-col items-center gap-2 group">
                        <div className="bg-yellow-50 p-4 rounded-full group-hover:bg-yellow-100 transition text-yellow-600">
                            <Zap size={24} />
                        </div>
                        <span className="text-xs font-medium text-gray-600">Electricity</span>
                    </button>
                    <button className="flex flex-col items-center gap-2 group">
                        <div className="bg-orange-50 p-4 rounded-full group-hover:bg-orange-100 transition text-orange-600">
                            <Flame size={24} />
                        </div>
                        <span className="text-xs font-medium text-gray-600">Gas</span>
                    </button>
                </div>
            </div>

            {/* Cylinder Tracker Special Widget */}
            {bills.filter(b => b.type === 'Gas Cylinder').map(gas => {
                const daysSince = Math.floor((Date.now() - new Date(gas.lastPaid || '').getTime()) / (1000 * 3600 * 24));
                const daysLeft = 45 - daysSince; // Assume 45 day cycle
                
                return (
                    <div key={gas.id} className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-xl p-6 flex flex-col md:flex-row justify-between items-center gap-4 shadow-sm">
                        <div className="flex items-center gap-4">
                            <div className="bg-white p-3 rounded-full shadow-sm text-orange-600">
                                <Flame size={32} />
                            </div>
                            <div>
                                <h3 className="font-bold text-orange-900">Gas Cylinder Tracker</h3>
                                <p className="text-orange-700 text-sm font-medium">{gas.provider}</p>
                                <p className="text-xs text-orange-600 mt-1">Booked: {new Date(gas.lastPaid || '').toLocaleDateString()} ({daysSince} days ago)</p>
                            </div>
                        </div>
                        <div className="text-center md:text-right flex flex-col items-center md:items-end">
                            <div className="text-2xl font-bold text-orange-800">{daysLeft > 0 ? `${daysLeft} Days Left` : 'Refill Due'}</div>
                            <p className="text-xs text-orange-600 mb-3">Estimated usage</p>
                            <button 
                                onClick={() => handlePayClick(gas)}
                                className="bg-orange-600 text-white px-6 py-2 rounded-lg text-sm font-bold hover:bg-orange-700 transition shadow-orange-200 shadow-lg"
                            >
                                Book Now (₹{gas.amount})
                            </button>
                        </div>
                    </div>
                )
            })}

            {/* Your Bills List */}
            <div>
                <h3 className="font-semibold text-gray-700 mb-4">Your Saved Bills</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {bills.filter(b => b.type !== 'Gas Cylinder').map(bill => {
                        const isDue = bill.dueDate ? new Date(bill.dueDate).getTime() < Date.now() + 86400000 * 3 : false;
                        
                        return (
                            <div key={bill.id} className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm hover:shadow-md transition">
                                <div className="flex justify-between items-start mb-4">
                                    <div className="flex items-center gap-3">
                                        <div className="bg-gray-50 p-2 rounded-lg">
                                            {getIcon(bill.type)}
                                        </div>
                                        <div>
                                            <h4 className="font-semibold text-gray-800">{bill.type}</h4>
                                            <p className="text-xs text-gray-500">{bill.provider}</p>
                                            {bill.identifier && <p className="text-[10px] text-gray-400 font-mono mt-0.5">{bill.identifier}</p>}
                                        </div>
                                    </div>
                                    <span className="font-bold text-gray-800">₹{bill.amount}</span>
                                </div>

                                {bill.dueDate && (
                                    <div className="flex items-center gap-2 text-xs mb-4">
                                        {isDue ? <AlertTriangle size={14} className="text-red-500"/> : <CheckCircle size={14} className="text-green-500"/>}
                                        <span className={isDue ? "text-red-500 font-medium" : "text-gray-500"}>
                                            Due: {new Date(bill.dueDate).toLocaleDateString()}
                                        </span>
                                    </div>
                                )}

                                <button 
                                    onClick={() => handlePayClick(bill)}
                                    className="w-full bg-indigo-50 text-indigo-600 py-2 rounded-lg text-sm font-medium hover:bg-indigo-100 transition"
                                >
                                    Pay Bill
                                </button>
                            </div>
                        )
                    })}
                </div>
            </div>

            {/* Custom Amount Modal (Fastag) */}
            {showAmountModal && (
                <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
                    <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl animate-fade-in p-6">
                        <div className="flex justify-between items-center mb-6">
                            <h3 className="font-bold text-gray-800">Recharge Fastag</h3>
                            <button onClick={() => setShowAmountModal(false)} className="text-gray-400 hover:text-gray-600">
                                <X size={20} />
                            </button>
                        </div>
                        <form onSubmit={handleCustomAmountSubmit}>
                            <label className="block text-xs font-bold text-gray-600 uppercase mb-2">Vehicle / Wallet ID</label>
                            <input 
                                type="text" 
                                className="w-full border border-gray-300 rounded-lg p-3 mb-4 bg-gray-50 font-mono text-sm"
                                placeholder="KA-01-MJ-1234"
                                defaultValue="KA-01-MJ-1234"
                            />
                            
                            <label className="block text-xs font-bold text-gray-600 uppercase mb-2">Amount</label>
                            <div className="relative mb-2">
                                <span className="absolute left-3 top-3.5 text-gray-500">₹</span>
                                <input 
                                    type="number" 
                                    value={customAmount}
                                    onChange={(e) => { setCustomAmount(e.target.value); setAmountError(''); }}
                                    className="w-full pl-8 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none font-bold text-lg"
                                    placeholder="Enter Amount"
                                    autoFocus
                                />
                            </div>
                            {amountError ? (
                                <p className="text-red-500 text-xs mb-4">{amountError}</p>
                            ) : (
                                <p className="text-gray-400 text-xs mb-6">Minimum recharge amount is ₹100</p>
                            )}

                            <button 
                                type="submit" 
                                className="w-full bg-purple-600 text-white py-3 rounded-lg font-bold hover:bg-purple-700 transition"
                            >
                                Proceed to Pay
                            </button>
                        </form>
                    </div>
                </div>
            )}

            {/* Mobile Plan Selection Modal */}
            {showRechargeModal && (
                <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
                    <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl animate-fade-in flex flex-col max-h-[85vh]">
                        <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50 rounded-t-2xl">
                            <div>
                                <h3 className="font-bold text-gray-800">Mobile Recharge</h3>
                                <p className="text-xs text-gray-500">Select a plan for your number</p>
                            </div>
                            <button onClick={() => setShowRechargeModal(false)} className="text-gray-400 hover:text-gray-600"><X size={20} /></button>
                        </div>
                        
                        <div className="p-4 border-b border-gray-100">
                            <input 
                                type="text" 
                                placeholder="Enter Mobile Number" 
                                value={rechargeNumber}
                                onChange={(e) => setRechargeNumber(e.target.value)}
                                className="w-full border border-gray-300 rounded-lg p-3 text-lg font-mono focus:ring-2 focus:ring-blue-500 outline-none"
                            />
                        </div>

                        {/* Plan Category Tabs */}
                        <div className="flex overflow-x-auto p-2 gap-2 border-b border-gray-100">
                            {['Daily Plans', 'Monthly Plans', 'Yearly Plans', 'Top-up'].map(cat => (
                                <button
                                    key={cat}
                                    onClick={() => setSelectedPlanCategory(cat as any)}
                                    className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                                        selectedPlanCategory === cat 
                                        ? 'bg-blue-600 text-white shadow-md' 
                                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                                    }`}
                                >
                                    {cat}
                                </button>
                            ))}
                        </div>

                        {/* Plans List */}
                        <div className="overflow-y-auto p-4 space-y-3 flex-1 bg-gray-50">
                            {filteredPlans.length > 0 ? filteredPlans.map(plan => (
                                <div key={plan.id} className="bg-white p-4 rounded-xl border border-gray-200 hover:border-blue-400 hover:shadow-md transition cursor-pointer" onClick={() => handlePlanSelect(plan)}>
                                    <div className="flex justify-between items-start mb-2">
                                        <div className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide">
                                            {plan.validity}
                                        </div>
                                        <div className="font-bold text-lg text-gray-800 flex items-center">
                                            <IndianRupee size={16} strokeWidth={3} />{plan.price}
                                        </div>
                                    </div>
                                    <div className="flex justify-between items-center">
                                        <div>
                                            <div className="flex items-center gap-2 font-bold text-gray-700">
                                                <Signal size={16} /> {plan.data}
                                            </div>
                                            <p className="text-xs text-gray-500 mt-1">{plan.description}</p>
                                            {plan.calls !== 'N/A' && <p className="text-xs text-green-600 font-medium mt-1">Calls: {plan.calls}</p>}
                                        </div>
                                        <button className="bg-white border border-blue-600 text-blue-600 px-4 py-1.5 rounded-lg text-sm font-bold hover:bg-blue-50">
                                            Select
                                        </button>
                                    </div>
                                </div>
                            )) : (
                                <div className="text-center text-gray-400 py-8">
                                    No plans found in this category.
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* Secure Payment Modal */}
            <PaymentModal 
                isOpen={showPaymentModal}
                amount={payAmount}
                payee={payeeName}
                onClose={() => setShowPaymentModal(false)}
                onSuccess={handlePaymentSuccess}
            />
        </div>
    );
};

export default Bills;
