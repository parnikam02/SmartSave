

import React, { useEffect, useState } from 'react';
import { getWallet, saveWallet, saveTransaction, getBankAccounts, processSalary } from '../services/storageService';
import { WalletState, TransactionType, Category, BankAccount } from '../types';
import { PiggyBank, CreditCard, ToggleLeft, ToggleRight, Check, Coins, PieChart, ArrowRight, Settings2, X, Landmark } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const WalletPage: React.FC = () => {
  const [wallet, setWallet] = useState<WalletState | null>(null);
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [addAmount, setAddAmount] = useState('');
  
  // Salary Splitter State
  const [salaryMode, setSalaryMode] = useState(false);
  const [salaryAmount, setSalaryAmount] = useState<string>('');
  const [selectedBankId, setSelectedBankId] = useState<string>('');
  
  // Percentage Config State
  const [percentages, setPercentages] = useState<Record<string, number>>({
      'Savings': 20,
      [Category.BILLS]: 30,
      [Category.FOOD]: 20,
      [Category.TRAVEL]: 10,
      [Category.OTHERS]: 20
  });

  // Auto Save Modal State
  const [showAutoSaveModal, setShowAutoSaveModal] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    setWallet(getWallet());
    const allBanks = getBankAccounts();
    setBanks(allBanks);
    // Auto-select "Salary Acct" if exists
    const salAcct = allBanks.find(b => b.bankName.includes('SBI') || b.name.includes('Salary'));
    if (salAcct) setSelectedBankId(salAcct.id);
    else if (allBanks.length > 0) setSelectedBankId(allBanks[0].id);
  }, []);

  const handleToggleAutoSave = () => {
    if (!wallet) return;

    if (wallet.autoSaveEnabled) {
        // Disable it directly
        const updated = { ...wallet, autoSaveEnabled: false, autoSaveSourceBankId: undefined };
        setWallet(updated);
        saveWallet(updated);
    } else {
        // Open modal to select source bank
        setShowAutoSaveModal(true);
    }
  };

  const activateAutoSave = (bankId: string) => {
    if (!wallet) return;
    const updated = { ...wallet, autoSaveEnabled: true, autoSaveSourceBankId: bankId };
    setWallet(updated);
    saveWallet(updated);
    setShowAutoSaveModal(false);
  };

  const handleAddFunds = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addAmount || isNaN(Number(addAmount)) || !wallet) return;
    
    const amount = parseFloat(addAmount);
    
    saveTransaction({
        id: Date.now().toString(),
        amount: amount,
        category: Category.OTHERS,
        description: 'Wallet Deposit',
        date: new Date().toISOString(),
        type: TransactionType.INCOME
    });

    setWallet(getWallet());
    setAddAmount('');
    navigate('/');
  };

  const handleImplementPlan = () => {
      const amt = parseFloat(salaryAmount);
      if (!amt || isNaN(amt)) return;

      // Validate percentages
      const totalPct = Object.values(percentages).reduce((sum: number, val: number) => sum + val, 0);
      if (totalPct !== 100) {
          alert(`Total percentages must equal 100%. Current total: ${totalPct}%`);
          return;
      }

      // Calculate amounts based on custom percentages
      const salaryPlan: Record<string, number> = {};
      Object.keys(percentages).forEach(key => {
          salaryPlan[key] = (amt * percentages[key]) / 100;
      });

      processSalary(amt, selectedBankId, salaryPlan);
      
      setSalaryMode(false);
      setSalaryAmount('');
      setWallet(getWallet()); // refresh
      navigate('/');
  };

  const handlePercentageChange = (key: string, value: string) => {
      const val = parseInt(value) || 0;
      setPercentages(prev => ({ ...prev, [key]: val }));
  };

  const currentTotalPercentage = Object.values(percentages).reduce((a: number, b: number) => a + b, 0);

  if (!wallet) return <div>Loading...</div>;

  const currentAutoSaveBank = banks.find(b => b.id === wallet.autoSaveSourceBankId);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-800">My Wallet</h2>

      {/* Salary Allocator Widget */}
      <div className="bg-indigo-600 rounded-2xl p-6 text-white shadow-lg">
          <div className="flex justify-between items-start">
             <div>
                 <h3 className="text-xl font-bold flex items-center gap-2"><Coins /> Smart Salary Allocator</h3>
                 <p className="text-indigo-200 text-sm mt-1">Custom split your salary into needs, wants, and savings.</p>
             </div>
             <button 
                onClick={() => setSalaryMode(!salaryMode)} 
                className="bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg text-sm font-semibold transition"
             >
                 {salaryMode ? 'Close' : 'Process Salary'}
             </button>
          </div>

          {salaryMode && (
              <div className="mt-6 bg-white rounded-xl p-6 text-gray-800 animate-fade-in">
                  
                  {/* Step 1: Input Details */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Salary Account</label>
                            <select 
                            value={selectedBankId}
                            onChange={(e) => setSelectedBankId(e.target.value)}
                            className="w-full p-3 border border-gray-300 rounded-lg outline-none bg-gray-50"
                            >
                                {banks.map(b => (
                                    <option key={b.id} value={b.id}>{b.bankName} - {b.name}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Salary Amount (₹)</label>
                            <input 
                            type="number" 
                            value={salaryAmount}
                            onChange={(e) => setSalaryAmount(e.target.value)}
                            className="w-full p-3 border border-gray-300 rounded-lg outline-none font-bold text-lg bg-gray-50 focus:bg-white focus:ring-2 focus:ring-indigo-500"
                            placeholder="e.g. 50000"
                            />
                        </div>
                  </div>

                  {salaryAmount && (
                      <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
                          <h4 className="font-bold text-lg mb-4 flex items-center gap-2 text-indigo-700">
                              <Settings2 size={18} /> Configure Your Split Plan
                          </h4>
                          
                          <div className="space-y-3">
                              {Object.keys(percentages).map(key => {
                                  const amt = parseFloat(salaryAmount) || 0;
                                  const calcAmount = (amt * percentages[key]) / 100;
                                  return (
                                      <div key={key} className="flex items-center gap-3">
                                          <div className="w-24 font-medium text-gray-700">{key}</div>
                                          <div className="flex-1 relative">
                                              <input 
                                                type="range" 
                                                min="0" 
                                                max="100" 
                                                value={percentages[key]} 
                                                onChange={(e) => handlePercentageChange(key, e.target.value)}
                                                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                                              />
                                          </div>
                                          <div className="w-16 relative">
                                               <input 
                                                  type="number" 
                                                  value={percentages[key]}
                                                  onChange={(e) => handlePercentageChange(key, e.target.value)}
                                                  className="w-full p-1 text-center border rounded font-bold text-indigo-600"
                                               />
                                               <span className="absolute right-4 top-1 text-xs text-gray-400 hidden">%</span>
                                          </div>
                                          <div className="w-24 text-right font-mono text-gray-600 font-medium">
                                              ₹{calcAmount.toFixed(0)}
                                          </div>
                                      </div>
                                  );
                              })}
                          </div>

                          <div className="flex justify-between items-center mt-4 pt-4 border-t border-gray-200">
                              <div className={`font-bold ${currentTotalPercentage === 100 ? 'text-green-600' : 'text-red-500'}`}>
                                  Total: {currentTotalPercentage}%
                              </div>
                              <button 
                                onClick={handleImplementPlan}
                                disabled={currentTotalPercentage !== 100}
                                className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-indigo-700 transition flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                              >
                                  Implement Plan <ArrowRight size={18} />
                              </button>
                          </div>
                      </div>
                  )}
              </div>
          )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Balance Card */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 text-white p-8 rounded-2xl shadow-lg relative overflow-hidden">
             <div className="absolute top-0 right-0 p-8 opacity-10">
                 <CreditCard size={120} />
             </div>
             <p className="text-gray-400 font-medium mb-1">Current Balance</p>
             <h1 className="text-4xl font-bold mb-8">₹{wallet.totalBalance.toFixed(2)}</h1>
             
             <div className="flex gap-4">
                 <div>
                     <p className="text-gray-400 text-xs uppercase tracking-wider">Savings</p>
                     <p className="font-semibold text-green-400">₹{wallet.savings.toFixed(2)}</p>
                 </div>
                 <div className="border-l border-gray-700 pl-4">
                     <p className="text-gray-400 text-xs uppercase tracking-wider">Monthly Budget</p>
                     <p className="font-semibold text-blue-400">₹{wallet.monthlyBudget.toFixed(2)}</p>
                 </div>
             </div>
        </div>

        {/* Add Funds */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-700 mb-4">Add Manual Funds</h3>
            <form onSubmit={handleAddFunds} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-600 mb-1">Amount (₹)</label>
                    <input 
                        type="number" 
                        value={addAmount}
                        onChange={(e) => setAddAmount(e.target.value)}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none transition"
                        placeholder="e.g. 5000"
                        min="1"
                        required
                    />
                </div>
                <button type="submit" className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition">
                    Deposit Money
                </button>
            </form>
        </div>
      </div>

      {/* Auto Save Feature */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-start gap-4">
              <div className="bg-green-100 p-3 rounded-full text-green-600">
                  <PiggyBank size={32} />
              </div>
              <div>
                  <h3 className="text-lg font-bold text-gray-800">Smart Auto-Save</h3>
                  <p className="text-gray-500 text-sm max-w-md mt-1">
                      Automatically deduct <strong>₹10</strong> from your selected bank account and move it to your savings every day.
                  </p>
                  {currentAutoSaveBank && (
                      <p className="text-xs text-green-700 font-medium mt-2 bg-green-50 inline-block px-2 py-1 rounded">
                          Linked Account: {currentAutoSaveBank.bankName} - {currentAutoSaveBank.name}
                      </p>
                  )}
              </div>
          </div>

          <button 
            onClick={handleToggleAutoSave}
            className={`flex items-center gap-3 px-6 py-3 rounded-full font-semibold transition-all ${
                wallet.autoSaveEnabled 
                ? 'bg-green-600 text-white hover:bg-green-700' 
                : 'bg-gray-200 text-gray-600 hover:bg-gray-300'
            }`}
          >
              {wallet.autoSaveEnabled ? (
                  <> <ToggleRight size={24} /> Active </>
              ) : (
                  <> <ToggleLeft size={24} /> Inactive </>
              )}
          </button>
      </div>

      {wallet.autoSaveEnabled && (
          <div className="flex items-center gap-2 text-green-700 bg-green-50 p-4 rounded-lg text-sm border border-green-200">
              <Check size={16} /> 
              Auto-save is currently active. Next deduction will happen tomorrow if you visit the app.
          </div>
      )}

      {/* Auto Save Bank Selection Modal */}
      {showAutoSaveModal && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
              <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl animate-fade-in p-6">
                  <div className="flex justify-between items-center mb-6">
                      <div className="flex items-center gap-2 text-green-700">
                          <PiggyBank size={24} />
                          <h3 className="font-bold text-lg">Enable Auto-Save</h3>
                      </div>
                      <button onClick={() => setShowAutoSaveModal(false)} className="text-gray-400 hover:text-gray-600">
                          <X size={20} />
                      </button>
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-4">
                      Select which bank account you want to use for the daily <strong>₹10</strong> deduction.
                  </p>

                  <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                      {banks.filter(b => b.id !== 'cash').map(bank => (
                          <button
                            key={bank.id}
                            onClick={() => activateAutoSave(bank.id)}
                            className="w-full bg-gray-50 hover:bg-indigo-50 border border-gray-200 hover:border-indigo-300 p-3 rounded-lg flex items-center gap-3 transition group text-left"
                          >
                               <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ backgroundColor: bank.color }}>
                                   <Landmark size={14} />
                               </div>
                               <div>
                                   <div className="text-sm font-bold text-gray-800">{bank.bankName}</div>
                                   <div className="text-xs text-gray-500">{bank.name} • ₹{bank.balance}</div>
                               </div>
                          </button>
                      ))}
                  </div>
                  
                  {banks.filter(b => b.id !== 'cash').length === 0 && (
                      <p className="text-red-500 text-sm text-center py-4">
                          No connected bank accounts found. Please add a bank first.
                      </p>
                  )}

                  <button 
                    onClick={() => setShowAutoSaveModal(false)}
                    className="w-full mt-6 bg-gray-100 text-gray-600 py-3 rounded-lg font-medium hover:bg-gray-200"
                  >
                      Cancel
                  </button>
              </div>
          </div>
      )}
    </div>
  );
};

export default WalletPage;
