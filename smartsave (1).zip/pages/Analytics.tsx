
import React, { useEffect, useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { getTransactions, getBankAccounts } from '../services/storageService';
import { Transaction, TransactionType, Category, BankAccount } from '../types';
import { Filter, Calendar, Landmark } from 'lucide-react';

const COLORS = ['#6366f1', '#ec4899', '#10b981', '#f59e0b', '#8b5cf6', '#64748b'];

interface DailyBankStats {
    date: string;
    total: number;
    banks: { name: string; amount: number; color: string }[];
}

const Analytics: React.FC = () => {
  const [pieData, setPieData] = useState<{name: string, value: number}[]>([]);
  const [monthlyData, setMonthlyData] = useState<{name: string, amount: number}[]>([]);
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [selectedBankId, setSelectedBankId] = useState<string>('all');
  const [dailyBankStats, setDailyBankStats] = useState<DailyBankStats[]>([]);

  useEffect(() => {
    setBanks(getBankAccounts());
  }, []);

  useEffect(() => {
    const allTxs = getTransactions();
    
    // Filter by Bank
    let txs = allTxs;
    if (selectedBankId !== 'all') {
        txs = allTxs.filter(t => t.bankAccountId === selectedBankId);
    }

    const expenses = txs.filter(t => t.type === TransactionType.EXPENSE);

    // 1. Prepare Pie Chart Data (Category Wise)
    const categoryMap: Record<string, number> = {};
    Object.values(Category).forEach(c => categoryMap[c] = 0);
    
    expenses.forEach(t => {
      if (categoryMap[t.category] !== undefined) {
        categoryMap[t.category] += t.amount;
      }
    });

    const pData = Object.keys(categoryMap)
      .map(key => ({ name: key, value: categoryMap[key] }))
      .filter(item => item.value > 0);
    
    setPieData(pData);

    // 2. Prepare Bar Chart Data (Last 6 Months)
    const monthMap: Record<string, number> = {};
    const today = new Date();
    for(let i=5; i>=0; i--) {
        const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
        const monthName = d.toLocaleString('default', { month: 'short' });
        monthMap[monthName] = 0;
    }

    expenses.forEach(t => {
        const d = new Date(t.date);
        const monthName = d.toLocaleString('default', { month: 'short' });
        if (monthMap[monthName] !== undefined) {
            monthMap[monthName] += t.amount;
        }
    });

    const bData = Object.keys(monthMap).map(key => ({ name: key, amount: monthMap[key] }));
    setMonthlyData(bData);

    // 3. Prepare Daily Bank Spending (Global View)
    // We use 'allTxs' filtered by expenses, because this view is meant to show breakdown even if a single bank is selected above? 
    // Usually "Bank-wise breakdown" implies showing all banks. Let's use the full expense list for this specific section or respect filter?
    // The requirement says "separate sections where user can see from which bank how much he spent". This implies a comparative view. 
    // So we will use ALL expenses for this specific widget to show the comparison.
    
    const allExpenses = allTxs.filter(t => t.type === TransactionType.EXPENSE);
    const dateBankMap: Record<string, Record<string, number>> = {};
    
    allExpenses.forEach(t => {
        const dateStr = new Date(t.date).toDateString(); // Group by Day
        const bank = banks.find(b => b.id === t.bankAccountId);
        const bankName = bank ? bank.bankName : (t.paymentMode === 'Cash' ? 'Cash' : 'Unknown');
        
        if (!dateBankMap[dateStr]) dateBankMap[dateStr] = {};
        if (!dateBankMap[dateStr][bankName]) dateBankMap[dateStr][bankName] = 0;
        
        dateBankMap[dateStr][bankName] += t.amount;
    });

    const dailyStats: DailyBankStats[] = Object.keys(dateBankMap).map(date => {
        const bankBreakdown = Object.keys(dateBankMap[date]).map(bName => {
            const bAccount = banks.find(b => b.bankName === bName); // simplified match
            return {
                name: bName,
                amount: dateBankMap[date][bName],
                color: bAccount?.color || (bName === 'Cash' ? '#10b981' : '#cbd5e1')
            };
        });
        const total = bankBreakdown.reduce((sum, item) => sum + item.amount, 0);
        return { date, banks: bankBreakdown, total };
    });

    // Sort by Date Descending
    dailyStats.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    setDailyBankStats(dailyStats);

  }, [selectedBankId, banks]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h2 className="text-2xl font-bold text-gray-800">Analytics & Insights</h2>
        
        {/* Bank Filter */}
        <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-lg border border-gray-200 shadow-sm">
            <Filter size={16} className="text-gray-400" />
            <select 
                value={selectedBankId} 
                onChange={(e) => setSelectedBankId(e.target.value)}
                className="bg-transparent outline-none text-sm text-gray-700 font-medium cursor-pointer min-w-[150px]"
            >
                <option value="all">All Accounts</option>
                {banks.map(b => (
                    <option key={b.id} value={b.id}>{b.bankName} - {b.name}</option>
                ))}
            </select>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Category Breakdown */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Expense by Category {selectedBankId !== 'all' && '(Filtered)'}</h3>
          {pieData.length > 0 ? (
            <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                    <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    fill="#8884d8"
                    paddingAngle={5}
                    dataKey="value"
                    >
                    {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                    </Pie>
                    <RechartsTooltip formatter={(value) => `₹${value}`} />
                    <Legend />
                </PieChart>
                </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center text-gray-400">
                No data for selected period/bank
            </div>
          )}
        </div>

        {/* Monthly Trend */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-700 mb-4">Monthly Trends {selectedBankId !== 'all' && '(Filtered)'}</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <RechartsTooltip formatter={(value) => `₹${value}`} cursor={{fill: 'transparent'}} />
                <Bar dataKey="amount" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      {/* Insight Card */}
      <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-xl">
          <h4 className="text-indigo-800 font-semibold mb-2">Spending Insight</h4>
          <p className="text-indigo-700 text-sm">
             {selectedBankId === 'all' 
                ? "You are viewing combined data from all 4 banks. This gives you a holistic view of your financial health."
                : "You are filtering by a specific bank. This helps you track which account is draining the fastest!"}
             {pieData.length > 0 && ` Currently, ${pieData.sort((a,b) => b.value - a.value)[0].name} is the highest expense.`}
          </p>
      </div>

      {/* New Section: Daily Bank Spending History */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-100 bg-gray-50">
              <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                  <Landmark className="text-indigo-600" /> Bank-wise Daily Spending History
              </h3>
              <p className="text-sm text-gray-500">Breakdown of how much you spent from each bank, day by day.</p>
          </div>
          <div className="divide-y divide-gray-100 max-h-[500px] overflow-y-auto">
              {dailyBankStats.length === 0 ? (
                  <div className="p-8 text-center text-gray-400">No transaction history found.</div>
              ) : (
                  dailyBankStats.map((stat, idx) => (
                      <div key={idx} className="p-4 hover:bg-gray-50 transition">
                          <div className="flex justify-between items-center mb-3">
                               <div className="flex items-center gap-2">
                                   <Calendar size={16} className="text-gray-400" />
                                   <span className="font-semibold text-gray-700">
                                       {new Date(stat.date).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}
                                   </span>
                               </div>
                               <span className="font-bold text-gray-900">Total: ₹{stat.total}</span>
                          </div>
                          
                          <div className="flex flex-wrap gap-3">
                              {stat.banks.map((bank, bIdx) => (
                                  <div key={bIdx} className="flex items-center gap-2 bg-white border border-gray-200 px-3 py-1.5 rounded-lg shadow-sm">
                                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: bank.color }}></div>
                                      <span className="text-xs font-medium text-gray-600">{bank.name}</span>
                                      <span className="text-sm font-bold text-gray-800">₹{bank.amount}</span>
                                  </div>
                              ))}
                          </div>
                      </div>
                  ))
              )}
          </div>
      </div>

    </div>
  );
};

export default Analytics;
