
import React, { useEffect, useState } from 'react';
import { getTransactions, getWallet, processAutoSave, connectBank, syncUPITransactions, getDebts, markDebtPaid, getBankAccounts, getSprints, updateSprintProgress, checkBudgetAndReward, getRewards, addBankAccount, verifyAppPassword, logoutUser, getCurrentUser } from '../services/storageService';
import { Transaction, WalletState, TransactionType, Debt, BankAccount, SavingsSprint, Reward, Category, User } from '../types';
import RecentTransactions from '../components/RecentTransactions';
import { Wallet, TrendingDown, PiggyBank, ArrowUpRight, RefreshCw, Smartphone, CheckCircle, AlertCircle, Clock, CreditCard, Landmark, Target, Gift, ReceiptText, Plane, PieChart, Plus, X, Eye, EyeOff, LogOut, Lock, User as UserIcon } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [wallet, setWallet] = useState<WalletState | null>(null);
  const [debts, setDebts] = useState<Debt[]>([]);
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [sprints, setSprints] = useState<SavingsSprint[]>([]);
  const [rewards, setRewards] = useState<Reward[]>([]);
  const [totalExpenses, setTotalExpenses] = useState(0);
  const [categoryExpenses, setCategoryExpenses] = useState<Record<string, number>>({});
  const [toast, setToast] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  // Add Bank Modal State
  const [showAddBank, setShowAddBank] = useState(false);
  const [newBankName, setNewBankName] = useState('');
  const [newBankProvider, setNewBankProvider] = useState('');
  const [newBankBalance, setNewBankBalance] = useState('');
  const [newBankHolder, setNewBankHolder] = useState('');
  const [newBankAccNo, setNewBankAccNo] = useState('');
  const [newBankIfsc, setNewBankIfsc] = useState('');

  // Bank Detail Reveal State
  const [selectedBank, setSelectedBank] = useState<BankAccount | null>(null);
  const [isDetailsRevealed, setIsDetailsRevealed] = useState(false);
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');

  const navigate = useNavigate();

  const loadData = () => {
    const txs = getTransactions();
    const currentWallet = getWallet();
    const currentDebts = getDebts();
    const currentBanks = getBankAccounts();
    const currentSprints = getSprints();
    const currentRewards = getRewards();
    const currentUser = getCurrentUser();

    setTransactions(txs);
    setWallet(currentWallet);
    setDebts(currentDebts);
    setBanks(currentBanks);
    setSprints(currentSprints);
    setRewards(currentRewards);
    setUser(currentUser);

    const currentMonth = new Date().getMonth();
    const monthExpenses = txs.filter(t => t.type === TransactionType.EXPENSE && new Date(t.date).getMonth() === currentMonth);
    
    setTotalExpenses(monthExpenses.reduce((sum, t) => sum + t.amount, 0));

    // Calculate category wise expenses
    const catExp: Record<string, number> = {};
    monthExpenses.forEach(t => {
        catExp[t.category] = (catExp[t.category] || 0) + t.amount;
    });
    setCategoryExpenses(catExp);
  };

  useEffect(() => {
    loadData();
    const { processed, message } = processAutoSave();
    if (processed) {
      showToast(message);
      loadData();
    }
  }, []);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 5000);
  };

  const handleConnectBank = () => {
    connectBank();
    loadData();
    showToast("Successfully connected to GPay & PhonePe!");
  };

  const handleSync = () => {
    if (!wallet?.bankConnected) return;
    setIsSyncing(true);
    setTimeout(() => {
      const { count, transactions: newTxs } = syncUPITransactions();
      checkBudgetAndReward(); // Check for rewards after sync
      loadData();
      setIsSyncing(false);
      if (count > 0) {
        showToast(`Synced ${count} new transactions!`);
      } else {
        showToast("No new transactions found.");
      }
    }, 1500);
  };

  const handleMarkPaid = (id: string) => {
      markDebtPaid(id);
      loadData();
      showToast("Great job! Debt marked as paid.");
  };

  const handleAddToSprint = (sprintId: string) => {
      updateSprintProgress(sprintId, 100); 
      loadData();
      showToast("Added ₹100 to your Agile Sprint!");
  }

  const handleAddBank = (e: React.FormEvent) => {
      e.preventDefault();
      if (!newBankName || !newBankProvider || !newBankBalance) return;
      
      const newBank: BankAccount = {
          id: `b-${Date.now()}`,
          name: newBankName,
          bankName: newBankProvider,
          holderName: newBankHolder || user?.name || 'User',
          balance: parseFloat(newBankBalance),
          color: '#' + Math.floor(Math.random()*16777215).toString(16),
          accountNumber: newBankAccNo || 'XXXX-XXXX-' + Math.floor(1000 + Math.random() * 9000),
          ifsc: newBankIfsc || 'NEW000' + Math.floor(1000 + Math.random() * 9000)
      };

      addBankAccount(newBank);
      loadData();
      setShowAddBank(false);
      // Reset
      setNewBankName('');
      setNewBankProvider('');
      setNewBankBalance('');
      setNewBankHolder('');
      setNewBankAccNo('');
      setNewBankIfsc('');
      showToast("New Bank Account Added Successfully!");
  }

  const handleBankCardClick = (bank: BankAccount) => {
      setSelectedBank(bank);
      setIsDetailsRevealed(false); // Reset reveal state on open
  };

  const handleRevealRequest = () => {
      setShowPasswordPrompt(true);
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (verifyAppPassword(passwordInput)) {
          setIsDetailsRevealed(true);
          setShowPasswordPrompt(false);
          setPasswordInput('');
      } else {
          alert('Incorrect Password');
      }
  };

  const handleLogout = () => {
      logoutUser();
      navigate('/login');
  };

  if (!wallet) return <div>Loading...</div>;

  const unpaidDebts = debts.filter(d => !d.isPaid);
  const activeSprint = sprints.find(s => s.status === 'Active');
  const budgetProgress = Math.min((totalExpenses / wallet.monthlyBudget) * 100, 100);
  const latestReward = rewards.length > 0 ? rewards[0] : null;

  return (
    <div className="space-y-6 relative pb-20 md:pb-0">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Welcome, {user?.name || 'User'}</h2>
          <span className="text-sm text-gray-500">Agile Finance Tracker • {new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
        </div>
        
        <div className="flex items-center gap-2">
            {wallet.bankConnected && (
            <button 
                onClick={handleSync}
                disabled={isSyncing}
                className="flex items-center gap-2 bg-white border border-gray-200 text-indigo-600 px-4 py-2 rounded-lg hover:bg-gray-50 transition shadow-sm"
            >
                <RefreshCw size={18} className={isSyncing ? "animate-spin" : ""} />
                {isSyncing ? 'Syncing...' : 'Sync Banks'}
            </button>
            )}
            <button onClick={handleLogout} className="bg-gray-100 p-2 rounded-lg hover:bg-gray-200 text-gray-600">
                <LogOut size={20} />
            </button>
        </div>
      </div>

      {toast && (
        <div className="bg-indigo-600 text-white px-4 py-3 rounded-lg shadow-lg flex items-center justify-between animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle size={20} />
            <span className="font-medium">{toast}</span>
          </div>
        </div>
      )}

      {/* Shortcuts */}
      <div className="grid grid-cols-2 gap-4">
           <Link to="/bills" className="bg-indigo-50 hover:bg-indigo-100 p-4 rounded-xl flex items-center justify-center gap-2 text-indigo-700 font-semibold transition">
                <ReceiptText size={20} /> Pay Bills & Recharge
           </Link>
           <Link to="/lifestyle" className="bg-teal-50 hover:bg-teal-100 p-4 rounded-xl flex items-center justify-center gap-2 text-teal-700 font-semibold transition">
                <Plane size={20} /> Plan Travel & Food
           </Link>
      </div>

      {/* Monthly Budget & Rewards Widget */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-gray-100">
             <div className="flex justify-between items-center mb-4">
                 <h3 className="font-bold text-gray-800 flex items-center gap-2"><CreditCard size={18} /> Monthly Budget Tracker</h3>
                 <span className="text-sm font-medium text-gray-500">₹{totalExpenses} / ₹{wallet.monthlyBudget}</span>
             </div>
             <div className="w-full bg-gray-200 rounded-full h-4 mb-2">
                 <div 
                    className={`h-4 rounded-full transition-all duration-500 ${budgetProgress > 90 ? 'bg-red-500' : 'bg-green-500'}`}
                    style={{ width: `${budgetProgress}%` }}
                 ></div>
             </div>
             <p className="text-xs text-gray-500 mb-4">
                 {budgetProgress < 100 ? "You are within budget. Keep it up to earn rewards!" : "You have exceeded your monthly budget."}
             </p>

             {/* Specific Category Breakdown (if plan is set) */}
             {wallet.categoryBudgets && Object.keys(wallet.categoryBudgets).length > 0 && (
                 <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-gray-100">
                     {[Category.FOOD, Category.BILLS, Category.TRAVEL].map(cat => {
                         const limit = wallet.categoryBudgets[cat] || 1;
                         const spent = categoryExpenses[cat] || 0;
                         const pct = Math.min((spent / limit) * 100, 100);
                         return (
                             <div key={cat} className="bg-gray-50 p-2 rounded">
                                 <div className="flex justify-between text-xs mb-1">
                                    <span className="font-medium text-gray-600">{cat}</span>
                                    <span>{Math.round(pct)}%</span>
                                 </div>
                                 <div className="w-full bg-gray-200 h-1.5 rounded-full">
                                     <div className={`h-1.5 rounded-full ${pct > 90 ? 'bg-red-400' : 'bg-indigo-400'}`} style={{width: `${pct}%`}}></div>
                                 </div>
                             </div>
                         )
                     })}
                 </div>
             )}
          </div>
          
          <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-6 rounded-xl text-white shadow-md relative overflow-hidden">
               <div className="absolute -right-4 -top-4 text-white/20">
                   <Gift size={100} />
               </div>
               <h3 className="font-bold text-lg mb-1">Rewards</h3>
               {latestReward ? (
                   <div>
                       <p className="text-yellow-100 text-sm">Latest Unlock:</p>
                       <p className="font-bold text-2xl">{latestReward.value}</p>
                       <p className="text-xs mt-2 bg-white/20 inline-block px-2 py-1 rounded">Unlocked: {new Date(latestReward.dateEarned).toLocaleDateString()}</p>
                   </div>
               ) : (
                   <div className="h-full flex flex-col justify-center">
                       <p className="font-medium">Stay under budget to win scratch cards!</p>
                   </div>
               )}
          </div>
      </div>

      {/* Agile Sprint Widget */}
      {activeSprint && (
          <div className="bg-gradient-to-r from-violet-600 to-indigo-600 rounded-xl p-4 text-white shadow-lg">
              <div className="flex justify-between items-center mb-2">
                  <h3 className="font-bold flex items-center gap-2"><Target size={20} /> Agile Savings Sprint</h3>
                  <span className="text-xs bg-white/20 px-2 py-1 rounded">Ends {new Date(activeSprint.endDate).toLocaleDateString()}</span>
              </div>
              <p className="text-indigo-100 text-sm mb-3">{activeSprint.name}</p>
              
              <div className="w-full bg-black/20 rounded-full h-3 mb-2">
                  <div 
                    className="bg-green-400 h-3 rounded-full transition-all duration-500" 
                    style={{ width: `${Math.min((activeSprint.currentAmount / activeSprint.targetAmount) * 100, 100)}%` }}
                  ></div>
              </div>
              
              <div className="flex justify-between items-center">
                  <span className="text-sm font-semibold">₹{activeSprint.currentAmount} / ₹{activeSprint.targetAmount}</span>
                  <button 
                    onClick={() => handleAddToSprint(activeSprint.id)}
                    className="bg-white text-indigo-700 text-xs px-3 py-1.5 rounded-lg font-bold hover:bg-indigo-50"
                  >
                      + Save ₹100
                  </button>
              </div>
          </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col justify-between h-32 relative overflow-hidden">
          <div className="absolute right-0 top-0 opacity-10 transform translate-x-2 -translate-y-2">
            <Wallet size={100} className="text-indigo-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Total Net Worth</p>
            <h3 className="text-3xl font-bold text-gray-900 mt-1">₹{wallet.totalBalance.toFixed(0)}</h3>
          </div>
          <div className="flex items-center text-xs text-indigo-600 font-medium">
             <span className="bg-indigo-50 px-2 py-1 rounded-full">All Accounts + Cash</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col justify-between h-32 relative overflow-hidden">
          <div className="absolute right-0 top-0 opacity-10 transform translate-x-2 -translate-y-2">
            <TrendingDown size={100} className="text-red-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">This Month's Spent</p>
            <h3 className="text-3xl font-bold text-gray-900 mt-1">₹{totalExpenses.toFixed(0)}</h3>
          </div>
          <div className="flex items-center text-xs text-red-600 font-medium">
             <span className="bg-red-50 px-2 py-1 rounded-full flex items-center gap-1">
                <TrendingDown size={12} /> Total Outflow
             </span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col justify-between h-32 relative overflow-hidden">
          <div className="absolute right-0 top-0 opacity-10 transform translate-x-2 -translate-y-2">
            <PiggyBank size={100} className="text-green-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Total Savings</p>
            <h3 className="text-3xl font-bold text-gray-900 mt-1">₹{wallet.savings.toFixed(0)}</h3>
          </div>
          <div className="flex items-center text-xs text-green-600 font-medium">
             <span className="bg-green-50 px-2 py-1 rounded-full flex items-center gap-1">
                <ArrowUpRight size={12} /> {wallet.autoSaveEnabled ? 'Auto-save ON' : 'Auto-save OFF'}
             </span>
          </div>
        </div>
      </div>

      {/* Bank Accounts List (Horizontal Scroll) */}
      <section>
          <h3 className="font-semibold text-gray-700 mb-3 flex items-center gap-2"><Landmark size={18} /> My Accounts</h3>
          <p className="text-xs text-gray-500 mb-2">Click on a card to view detailed information.</p>
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
              {/* Add New Bank Card */}
              <button 
                  onClick={() => setShowAddBank(true)}
                  className="min-w-[120px] bg-white border border-dashed border-gray-300 p-4 rounded-xl shadow-sm flex flex-col justify-center items-center text-gray-500 hover:border-indigo-400 hover:text-indigo-600 hover:bg-gray-50 transition"
              >
                  <Plus size={32} className="mb-2 opacity-50" />
                  <span className="text-xs font-semibold">Add Account</span>
              </button>

              {banks.map(bank => (
                  <div 
                    key={bank.id} 
                    onClick={() => handleBankCardClick(bank)}
                    className="min-w-[260px] bg-white border border-gray-200 p-4 rounded-xl shadow-sm flex flex-col justify-between relative overflow-hidden group hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer"
                  >
                      <div className="absolute top-0 right-0 w-24 h-24 rounded-full opacity-10 -mr-8 -mt-8" style={{ backgroundColor: bank.color }}></div>
                      
                      <div className="flex justify-between items-start mb-4">
                          <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">{bank.bankName}</p>
                          <div className="text-gray-400">
                             <Lock size={14} />
                          </div>
                      </div>

                      <div className="mb-3">
                          <h4 className="text-2xl font-bold text-gray-800">₹{bank.balance.toLocaleString()}</h4>
                          <p className="text-xs text-gray-500 mt-1">{bank.name}</p>
                      </div>

                      <div className="bg-gray-50 rounded p-2 text-xs text-gray-500 flex items-center gap-2">
                           <UserIcon size={12} /> {bank.holderName}
                      </div>
                  </div>
              ))}
          </div>
      </section>

      {/* Debt Reminders */}
      {unpaidDebts.length > 0 && (
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-4">
              <h3 className="text-orange-800 font-bold flex items-center gap-2 mb-3">
                  <AlertCircle size={20} /> Pending Debt Reminders
              </h3>
              <div className="space-y-2">
                  {unpaidDebts.map(debt => {
                      const daysLeft = Math.ceil((new Date(debt.dueDate).getTime() - Date.now()) / (1000 * 3600 * 24));
                      return (
                        <div key={debt.id} className="flex flex-col md:flex-row md:items-center justify-between bg-white p-3 rounded-lg shadow-sm">
                            <div className="flex items-center gap-3">
                                <div className="bg-orange-100 p-2 rounded-full text-orange-600">
                                    <Clock size={16} />
                                </div>
                                <div>
                                    <p className="font-semibold text-gray-800">Repay {debt.lender}</p>
                                    <p className="text-xs text-gray-500">Amount: <span className="font-bold text-gray-700">₹{debt.amount}</span> • Due: {new Date(debt.dueDate).toLocaleDateString()}</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-2 mt-2 md:mt-0">
                                <span className={`text-xs font-medium px-2 py-1 rounded ${daysLeft < 0 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                                    {daysLeft < 0 ? 'Overdue!' : `${daysLeft} days left`}
                                </span>
                                <button 
                                    onClick={() => handleMarkPaid(debt.id)}
                                    className="text-xs bg-indigo-600 text-white px-3 py-1.5 rounded hover:bg-indigo-700 transition"
                                >
                                    Mark Paid
                                </button>
                            </div>
                        </div>
                      );
                  })}
              </div>
          </div>
      )}

      {/* UPI Connection Banner */}
      {!wallet.bankConnected && (
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-6 text-white flex flex-col md:flex-row items-center justify-between shadow-lg">
          <div className="flex items-center gap-4 mb-4 md:mb-0">
            <div className="bg-white/20 p-3 rounded-full">
              <Smartphone size={32} />
            </div>
            <div>
              <h3 className="text-lg font-bold">Connect GPay & PhonePe</h3>
              <p className="text-blue-100 text-sm">Enable automatic multi-bank expense tracking.</p>
            </div>
          </div>
          <button 
            onClick={handleConnectBank}
            className="bg-white text-indigo-600 px-6 py-2 rounded-full font-bold hover:bg-blue-50 transition"
          >
            Connect Now
          </button>
        </div>
      )}

      <div>
        <RecentTransactions transactions={transactions} />
      </div>

      {/* Add Bank Modal */}
      {showAddBank && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
              <div className="bg-white rounded-2xl w-full max-w-sm shadow-2xl animate-fade-in my-8">
                  <div className="flex justify-between items-center p-4 border-b border-gray-100">
                      <h3 className="font-bold text-gray-800">Add Bank Account</h3>
                      <button onClick={() => setShowAddBank(false)} className="text-gray-400 hover:text-gray-600">
                          <X size={20} />
                      </button>
                  </div>
                  <form onSubmit={handleAddBank} className="p-4 space-y-4 max-h-[70vh] overflow-y-auto">
                      <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">Bank Name</label>
                          <input 
                            type="text" 
                            value={newBankProvider}
                            onChange={e => setNewBankProvider(e.target.value)}
                            className="w-full border border-gray-200 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            placeholder="e.g. HDFC Bank"
                            required
                          />
                      </div>
                      <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">Account Nickname</label>
                          <input 
                            type="text" 
                            value={newBankName}
                            onChange={e => setNewBankName(e.target.value)}
                            className="w-full border border-gray-200 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            placeholder="e.g. Salary Acct"
                            required
                          />
                      </div>
                      <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">Holder Name</label>
                          <input 
                            type="text" 
                            value={newBankHolder}
                            onChange={e => setNewBankHolder(e.target.value)}
                            className="w-full border border-gray-200 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            placeholder="e.g. John Doe"
                            required
                          />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1">Account Number</label>
                            <input 
                                type="text" 
                                value={newBankAccNo}
                                onChange={e => setNewBankAccNo(e.target.value)}
                                className="w-full border border-gray-200 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                                placeholder="XXXX1234"
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-medium text-gray-600 mb-1">IFSC Code</label>
                            <input 
                                type="text" 
                                value={newBankIfsc}
                                onChange={e => setNewBankIfsc(e.target.value)}
                                className="w-full border border-gray-200 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                                placeholder="HDFC000..."
                            />
                        </div>
                      </div>
                      <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">Initial Balance</label>
                          <input 
                            type="number" 
                            value={newBankBalance}
                            onChange={e => setNewBankBalance(e.target.value)}
                            className="w-full border border-gray-200 rounded-lg p-2.5 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                            placeholder="e.g. 10000"
                            required
                          />
                      </div>
                      <p className="text-xs text-gray-400 bg-gray-50 p-2 rounded border border-gray-100">
                          <Lock size={10} className="inline mr-1" />
                          Sensitive details like Account No. & IFSC will be hidden by default.
                      </p>
                      <button 
                        type="submit"
                        className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition"
                      >
                          Add Account
                      </button>
                  </form>
              </div>
          </div>
      )}

      {/* Selected Bank Detail Modal */}
      {selectedBank && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
               <div className="bg-white rounded-xl shadow-2xl w-full max-w-sm overflow-hidden animate-fade-in">
                   {/* Header */}
                   <div className="p-6 relative text-white" style={{ backgroundColor: selectedBank.color }}>
                       <button onClick={() => setSelectedBank(null)} className="absolute top-4 right-4 text-white/80 hover:text-white">
                           <X size={24} />
                       </button>
                       <p className="text-sm opacity-80 uppercase tracking-wider font-semibold">{selectedBank.bankName}</p>
                       <h3 className="text-3xl font-bold mt-2">₹{selectedBank.balance.toLocaleString()}</h3>
                       <p className="text-sm opacity-90 mt-1">{selectedBank.name}</p>
                   </div>

                   {/* Body */}
                   <div className="p-6">
                       <h4 className="text-gray-800 font-bold mb-4 flex items-center gap-2">
                           <Landmark size={18} /> Account Details
                       </h4>
                       
                       <div className="space-y-4">
                           <div className="flex justify-between items-center border-b border-gray-100 pb-2">
                               <span className="text-gray-500 text-sm">Account Holder</span>
                               <span className="font-medium text-gray-800">{selectedBank.holderName}</span>
                           </div>

                           <div className="flex justify-between items-center border-b border-gray-100 pb-2">
                               <span className="text-gray-500 text-sm">Account Number</span>
                               <div className="flex items-center gap-2">
                                   <span className="font-mono text-gray-800 bg-gray-100 px-2 py-1 rounded">
                                       {isDetailsRevealed ? selectedBank.accountNumber : `•••• •••• ${selectedBank.accountNumber.slice(-4)}`}
                                   </span>
                               </div>
                           </div>

                           <div className="flex justify-between items-center border-b border-gray-100 pb-2">
                               <span className="text-gray-500 text-sm">IFSC Code</span>
                               <span className="font-mono text-gray-800 bg-gray-100 px-2 py-1 rounded">
                                   {isDetailsRevealed ? selectedBank.ifsc : '•••••••'}
                               </span>
                           </div>
                       </div>

                       <div className="mt-8">
                           {!isDetailsRevealed ? (
                               <button 
                                onClick={handleRevealRequest}
                                className="w-full border border-indigo-600 text-indigo-600 py-3 rounded-lg font-semibold hover:bg-indigo-50 transition flex items-center justify-center gap-2"
                               >
                                   <Eye size={18} /> Reveal Sensitive Info
                               </button>
                           ) : (
                               <button 
                                onClick={() => setIsDetailsRevealed(false)}
                                className="w-full bg-gray-100 text-gray-600 py-3 rounded-lg font-semibold hover:bg-gray-200 transition flex items-center justify-center gap-2"
                               >
                                   <EyeOff size={18} /> Hide Info
                               </button>
                           )}
                       </div>
                   </div>
               </div>
          </div>
      )}

      {/* Password Prompt Modal */}
      {showPasswordPrompt && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[60] p-4 backdrop-blur-md">
               <div className="bg-white rounded-xl shadow-xl w-full max-w-xs p-6 animate-fade-in">
                   <div className="text-center mb-4">
                       <div className="bg-indigo-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-2 text-indigo-600">
                           <Lock size={20} />
                       </div>
                       <h3 className="font-bold text-gray-800">Security Check</h3>
                       <p className="text-xs text-gray-500">Enter your login password to view details.</p>
                   </div>
                   <form onSubmit={handlePasswordSubmit}>
                       <input 
                            type="password" 
                            value={passwordInput}
                            onChange={e => setPasswordInput(e.target.value)}
                            className="w-full border border-gray-300 rounded-lg p-2.5 mb-4 text-center tracking-widest outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                            placeholder="Password"
                            autoFocus
                       />
                       <div className="flex gap-2">
                           <button 
                                type="button" 
                                onClick={() => setShowPasswordPrompt(false)}
                                className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg text-sm font-medium hover:bg-gray-200"
                           >
                               Cancel
                           </button>
                           <button 
                                type="submit" 
                                className="flex-1 bg-indigo-600 text-white py-2 rounded-lg text-sm font-medium hover:bg-indigo-700"
                           >
                               Verify
                           </button>
                       </div>
                   </form>
               </div>
          </div>
      )}
    </div>
  );
};

export default Dashboard;
