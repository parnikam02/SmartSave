import React, { useState } from 'react';
import { getFinancialAdvice } from '../services/geminiService';
import { getTransactions, getWallet } from '../services/storageService';
import { Sparkles, Loader2, MessageSquare } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const Advisor: React.FC = () => {
  const [advice, setAdvice] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const handleGetAdvice = async () => {
    setLoading(true);
    const txs = getTransactions();
    const wallet = getWallet();
    
    // Check if user has enough data
    if (txs.length < 3) {
        setAdvice("I need a bit more data to analyze your habits. Please add at least 3 transactions.");
        setLoading(false);
        return;
    }

    const result = await getFinancialAdvice(txs, wallet);
    setAdvice(result);
    setLoading(false);
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="text-center space-y-2 mb-8">
          <div className="inline-block p-3 rounded-full bg-indigo-100 text-indigo-600 mb-2">
              <Sparkles size={32} />
          </div>
          <h2 className="text-3xl font-bold text-gray-800">AI Financial Advisor</h2>
          <p className="text-gray-500">Get personalized money-saving tips based on your actual spending habits.</p>
      </div>

      {!advice && (
        <div className="text-center py-10 bg-white rounded-xl shadow-sm border border-gray-100">
            <p className="text-gray-600 mb-6">Ready to see how you can save more money?</p>
            <button 
                onClick={handleGetAdvice}
                disabled={loading}
                className="bg-indigo-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-indigo-700 transition flex items-center gap-2 mx-auto disabled:opacity-70"
            >
                {loading ? <Loader2 className="animate-spin" /> : <Sparkles size={18} />}
                {loading ? 'Analyzing your finances...' : 'Analyze My Spending'}
            </button>
        </div>
      )}

      {advice && (
        <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
             <div className="bg-indigo-600 p-4 text-white flex items-center gap-2">
                 <MessageSquare size={20} />
                 <h3 className="font-semibold">Advisor's Report</h3>
             </div>
             <div className="p-8 prose prose-indigo max-w-none text-gray-700">
                <ReactMarkdown>{advice}</ReactMarkdown>
             </div>
             <div className="p-4 bg-gray-50 border-t border-gray-100 text-center">
                 <button 
                    onClick={handleGetAdvice} 
                    className="text-indigo-600 font-medium hover:text-indigo-800 text-sm"
                 >
                     Refresh Advice
                 </button>
             </div>
        </div>
      )}
    </div>
  );
};

export default Advisor;