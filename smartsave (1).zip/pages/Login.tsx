import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { loginUser, registerUser } from '../services/storageService';
import { Lock, Smartphone, ArrowRight, ShieldCheck, User, UserCog } from 'lucide-react';

const Login: React.FC = () => {
    const [mode, setMode] = useState<'login' | 'signup'>('login');
    const [roleMode, setRoleMode] = useState<'user' | 'admin'>('user'); // Toggle for login visual
    
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [error, setError] = useState('');
    const [successMsg, setSuccessMsg] = useState('');
    
    const navigate = useNavigate();

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccessMsg('');
        
        if (mode === 'login') {
            const result = loginUser(phone, password);
            if (result.success) {
                if (result.role === 'admin') navigate('/admin');
                else navigate('/');
            } else {
                setError('Invalid credentials. Please check your Phone/ID and Password.');
            }
        } else {
            // Register
            if (!name) {
                setError('Please enter your name');
                return;
            }
            const res = registerUser({ phone, name, password, role: 'user', isLoggedIn: true });
            if (res.success) {
                setSuccessMsg(res.message);
                setMode('login'); // Switch to login screen
                setPassword(''); // Clear password
            } else {
                setError(res.message);
            }
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col justify-center items-center p-4">
            <div className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden animate-fade-in">
                <div className={`p-8 text-center transition-all ${roleMode === 'admin' && mode === 'login' ? 'bg-gray-800' : 'bg-indigo-600'}`}>
                    <div className="bg-white/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 backdrop-blur-sm text-white">
                        {roleMode === 'admin' && mode === 'login' ? <UserCog size={32} /> : <Lock size={32} />}
                    </div>
                    <h1 className="text-2xl font-bold text-white">SmartSave</h1>
                    <p className="text-indigo-100 text-sm mt-2">
                        {mode === 'login' ? (roleMode === 'admin' ? 'Administrator Portal' : 'Secure User Login') : 'Create New Account'}
                    </p>
                </div>

                <form onSubmit={handleSubmit} className="p-8 space-y-5">
                    
                    {/* Mode Toggler (Login vs Signup) */}
                    <div className="flex bg-gray-100 p-1 rounded-lg mb-2">
                        <button 
                            type="button"
                            onClick={() => { setMode('login'); setError(''); setSuccessMsg(''); }} 
                            className={`flex-1 py-2 text-sm font-semibold rounded-md transition ${mode === 'login' ? 'bg-white shadow text-indigo-600' : 'text-gray-500'}`}
                        >
                            Log In
                        </button>
                        <button 
                            type="button"
                            onClick={() => { setMode('signup'); setError(''); setSuccessMsg(''); setRoleMode('user'); }}
                            className={`flex-1 py-2 text-sm font-semibold rounded-md transition ${mode === 'signup' ? 'bg-white shadow text-indigo-600' : 'text-gray-500'}`}
                        >
                            Sign Up
                        </button>
                    </div>

                    {/* Role Toggler (User vs Admin) - Only visible in Login mode */}
                    {mode === 'login' && (
                        <div className="flex justify-center gap-4 mb-4 text-sm">
                            <label className={`cursor-pointer flex items-center gap-2 ${roleMode === 'user' ? 'text-indigo-600 font-bold' : 'text-gray-400'}`}>
                                <input type="radio" name="role" className="hidden" onClick={() => setRoleMode('user')} />
                                <User size={16} /> User
                            </label>
                            <span className="text-gray-300">|</span>
                            <label className={`cursor-pointer flex items-center gap-2 ${roleMode === 'admin' ? 'text-gray-800 font-bold' : 'text-gray-400'}`}>
                                <input type="radio" name="role" className="hidden" onClick={() => setRoleMode('admin')} />
                                <UserCog size={16} /> Admin
                            </label>
                        </div>
                    )}

                    {mode === 'signup' && (
                        <div className="animate-fade-in">
                            <label className="block text-xs font-bold text-gray-600 uppercase mb-1">Full Name</label>
                            <div className="relative">
                                <User className="absolute left-3 top-3.5 text-gray-400" size={18} />
                                <input 
                                    type="text" 
                                    value={name}
                                    onChange={e => setName(e.target.value)}
                                    className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none transition"
                                    placeholder="Your Name"
                                    required={mode === 'signup'}
                                />
                            </div>
                        </div>
                    )}

                    <div>
                        <label className="block text-xs font-bold text-gray-600 uppercase mb-1">
                            {roleMode === 'admin' && mode === 'login' ? 'Admin ID / Username' : 'Phone Number'}
                        </label>
                        <div className="relative">
                            <Smartphone className="absolute left-3 top-3.5 text-gray-400" size={18} />
                            <input 
                                type="text" 
                                value={phone}
                                onChange={e => setPhone(e.target.value)}
                                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none transition"
                                placeholder={roleMode === 'admin' ? "Enter Admin ID (e.g. pari)" : "Enter mobile number"}
                                required
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-gray-600 uppercase mb-1">Password</label>
                        <div className="relative">
                            <Lock className="absolute left-3 top-3.5 text-gray-400" size={18} />
                            <input 
                                type="password" 
                                value={password}
                                onChange={e => setPassword(e.target.value)}
                                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none transition"
                                placeholder="Enter your password"
                                required
                            />
                        </div>
                    </div>

                    {error && <p className="text-red-500 text-sm text-center font-medium bg-red-50 p-2 rounded">{error}</p>}
                    {successMsg && <p className="text-green-600 text-sm text-center font-medium bg-green-50 p-2 rounded">{successMsg}</p>}

                    <button 
                        type="submit"
                        className={`w-full text-white py-3.5 rounded-xl font-bold hover:opacity-90 transition flex items-center justify-center gap-2 ${roleMode === 'admin' && mode === 'login' ? 'bg-gray-800' : 'bg-indigo-600'}`}
                    >
                        {mode === 'login' ? 'Login Securely' : 'Create Account'} <ArrowRight size={18} />
                    </button>

                    <div className="flex items-center justify-center gap-2 text-xs text-gray-400 mt-4">
                        <ShieldCheck size={14} className="text-green-500" />
                        <span>Bank-grade security enabled</span>
                    </div>
                </form>
            </div>
            <p className="mt-8 text-gray-400 text-xs">© 2024 SmartSave. Optimized for Mobile & Desktop.</p>
        </div>
    );
};

export default Login;