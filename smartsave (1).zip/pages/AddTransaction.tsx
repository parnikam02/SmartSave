import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { saveTransaction, addDebt, getBankAccounts } from '../services/storageService';
import { Category, TransactionType, PaymentMode, BankAccount } from '../types';
import { CreditCard, Banknote, Smartphone, Receipt, UserMinus, PlusCircle, Landmark } from 'lucide-react';

const AddTransaction: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'transaction' | 'debt'>('transaction');

  // Transaction State
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<Category>(Category.FOOD);
  const [type, setType] = useState<TransactionType>(TransactionType.EXPENSE);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('UPI');
  const [bankAccountId, setBankAccountId] = useState<string>('');
  
  const [banks, setBanks] = useState<BankAccount[]>([]);

  // Debt State
  const [lender, setLender] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [debtAmount, setDebtAmount] = useState('');

  useEffect(() => {
      const allBanks = getBankAccounts();
      setBanks(allBanks);
      if (allBanks.length > 0) {
          setBankAccountId(allBanks[0].id);
      }
  }, []);

  const handleTransactionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !description) return;

    // Use selected bank ID unless it's strictly cash manual override
    let finalBankId = bankAccountId;
    if (paymentMode === 'Cash') {
        const cashAcct = banks.find(b => b.id === 'cash');
        if (cashAcct) finalBankId = cashAcct.id;
    }

    saveTransaction({
      id: Date.now().toString(),
      amount: parseFloat(amount),
      category,
      description,
      date: new Date().toISOString(),
      type,
      source: 'Manual',
      paymentMode,
      bankAccountId: finalBankId
    });

    navigate('/');
  };

  const handleDebtSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!debtAmount || !lender || !dueDate) return;

    addDebt({
        id: Date.now().toString(),
        amount: parseFloat(debtAmount),
        lender,
        dueDate: new Date(dueDate).toISOString(),
        isPaid: false,
        notes: description
    });

    navigate('/');
  };

  return (
    <div className="max-w-xl mx-auto">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Add New Activity</h2>
      
      {/* Tabs */}
      <div className="flex bg-gray-200 p-1 rounded-lg mb-6">
          <button 
            onClick={() => setActiveTab('transaction')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-md text-sm font-semibold transition ${activeTab === 'transaction' ? 'bg-white shadow text-indigo-600' : 'text-gray-600'}`}
          >
              <Receipt size={18} /> Expense / Income
          </button>
          <button 
            onClick={() => setActiveTab('debt')}
            className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-md text-sm font-semibold transition ${activeTab === 'debt' ? 'bg-white shadow text-red-600' : 'text-gray-600'}`}
          >
              <UserMinus size={18} /> Borrow / Debt
          </button>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        
        {activeTab === 'transaction' ? (
            <form onSubmit={handleTransactionSubmit} className="space-y-5">
            {/* Type Toggle */}
            <div className="flex gap-4">
                <label className={`flex-1 cursor-pointer border-2 rounded-lg p-3 text-center transition ${type === TransactionType.EXPENSE ? 'border-red-500 bg-red-50 text-red-700 font-bold' : 'border-gray-200 text-gray-500'}`}>
                    <input type="radio" name="type" className="hidden" onClick={() => setType(TransactionType.EXPENSE)} />
                    Expense
                </label>
                <label className={`flex-1 cursor-pointer border-2 rounded-lg p-3 text-center transition ${type === TransactionType.INCOME ? 'border-green-500 bg-green-50 text-green-700 font-bold' : 'border-gray-200 text-gray-500'}`}>
                    <input type="radio" name="type" className="hidden" onClick={() => setType(TransactionType.INCOME)} />
                    Income
                </label>
            </div>

            {/* Amount */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Amount</label>
                <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <span className="text-gray-500 sm:text-sm">₹</span>
                </div>
                <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full pl-7 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="0.00"
                    required
                />
                </div>
            </div>

            {/* Description */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                placeholder="e.g. Lunch at Cafe"
                required
                />
            </div>

            {/* Category */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Category)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none bg-white"
                >
                {Object.values(Category).map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                ))}
                </select>
            </div>

            {/* Payment Mode */}
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Payment Mode</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {[
                        { id: 'UPI', label: 'Online/UPI', icon: Smartphone },
                        { id: 'Cash', label: 'Hard Cash', icon: Banknote },
                        { id: 'Credit Card', label: 'Credit Card', icon: CreditCard },
                        { id: 'Debit Card', label: 'Debit Card', icon: CreditCard }
                    ].map((mode) => (
                        <button
                            key={mode.id}
                            type="button"
                            onClick={() => setPaymentMode(mode.id as PaymentMode)}
                            className={`flex flex-col items-center justify-center p-3 rounded-lg border text-xs gap-1 transition ${paymentMode === mode.id ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-semibold' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
                        >
                            <mode.icon size={20} />
                            {mode.label}
                        </button>
                    ))}
                </div>
            </div>

            {/* Bank Selection (Only if not Cash) */}
            {paymentMode !== 'Cash' && (
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Bank Account</label>
                    <div className="relative">
                        <Landmark className="absolute left-3 top-3.5 text-gray-400" size={18} />
                        <select
                            value={bankAccountId}
                            onChange={(e) => setBankAccountId(e.target.value)}
                            className="w-full pl-10 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none bg-white"
                        >
                            {banks.filter(b => b.id !== 'cash').map(bank => (
                                <option key={bank.id} value={bank.id}>
                                    {bank.bankName} - {bank.name} (₹{bank.balance.toLocaleString()})
                                </option>
                            ))}
                        </select>
                    </div>
                </div>
            )}

            <button
                type="submit"
                className="w-full py-3 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition shadow-sm mt-4"
            >
                Save Transaction
            </button>
            </form>
        ) : (
            <form onSubmit={handleDebtSubmit} className="space-y-5">
                <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg text-sm text-yellow-800">
                    Add money you borrowed from friends or banks. We will remind you to pay it back!
                </div>

                {/* Lender Name */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Borrowed From (Name)</label>
                    <input
                    type="text"
                    value={lender}
                    onChange={(e) => setLender(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="e.g. Rahul, HDFC Bank"
                    required
                    />
                </div>

                {/* Amount */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Amount Borrowed</label>
                    <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <span className="text-gray-500 sm:text-sm">₹</span>
                    </div>
                    <input
                        type="number"
                        value={debtAmount}
                        onChange={(e) => setDebtAmount(e.target.value)}
                        className="w-full pl-7 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                        placeholder="0.00"
                        required
                    />
                    </div>
                </div>

                {/* Due Date */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                    <input
                        type="date"
                        value={dueDate}
                        onChange={(e) => setDueDate(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                        required
                    />
                </div>

                 {/* Notes */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Notes (Optional)</label>
                    <input
                    type="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="e.g. For movie tickets"
                    />
                </div>

                <button
                    type="submit"
                    className="w-full py-3 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition shadow-sm mt-4"
                >
                    Set Repayment Reminder
                </button>
            </form>
        )}
      </div>
    </div>
  );
};

export default AddTransaction;